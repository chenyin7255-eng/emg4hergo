import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
from pathlib import Path

# ========== 配置参数 ==========
RESULTS_ROOT = Path(r"")

CROP_START = 100          # 切掉前100个时间点
NORMALIZE_ATTN = True     # 是否对注意力权重归一化（min-max沿时间轴）
JOINTS = list(range(20))  # 绘制关节0～19，共20个

# 图形尺寸
FIGURE_WIDTH = 8          # 宽度（英寸）
HEIGHT_RATIOS = [0.8, 0.8, 1.2]  # 速度:加速度:热力图的高度比例
FIGURE_HEIGHT = 5.5       # 总高度（英寸）

FONT_FAMILY = 'Times New Roman'
FONT_SIZE = 12
LINE_WIDTH = 1.2          # 曲线稍细，避免重叠严重
DPI = 300

# 图例设置
SHOW_LEGEND = True        # 是否显示图例（20条曲线建议显示，但会较密集）
LEGEND_NCOL = 4           # 图例列数
LEGEND_FONTSIZE = 8       # 图例字体大小
# ============================

def set_style():
    plt.rcParams['font.family'] = FONT_FAMILY
    plt.rcParams['font.size'] = FONT_SIZE
    plt.rcParams['axes.labelsize'] = FONT_SIZE
    plt.rcParams['axes.titlesize'] = FONT_SIZE + 1
    plt.rcParams['xtick.labelsize'] = FONT_SIZE - 1
    plt.rcParams['ytick.labelsize'] = FONT_SIZE - 1
    plt.rcParams['legend.fontsize'] = LEGEND_FONTSIZE
    plt.rcParams['figure.dpi'] = DPI

def normalize_minmax(data, axis=1):
    """Min-max 归一化到 [0,1]"""
    min_val = data.min(axis=axis, keepdims=True)
    max_val = data.max(axis=axis, keepdims=True)
    range_val = max_val - min_val
    range_val[range_val == 0] = 1.0
    return (data - min_val) / range_val

def get_joint_color(idx):
    """
    根据关节索引 idx（0～19）返回颜色。
    每5个关节一个大色系：0-4红色系，5-9蓝色系，10-14绿色系，15-19橙色系。
    组内偏移 offset（0深～4浅），颜色向白色线性混合。
    """
    group = idx // 5          # 组号 (0:红, 1:蓝, 2:绿, 3:橙)
    offset = idx % 5          # 组内偏移 0～4
    base_colors = [
        [1.0, 0.0, 0.0],  # 红
        [0.0, 0.0, 1.0],  # 蓝
        [0.0, 0.8, 0.0],  # 绿
        [1.0, 0.5, 0.0],  # 橙
    ]
    base = np.array(base_colors[group % len(base_colors)])
    white = np.array([1.0, 1.0, 1.0])
    mix = 0.15 * offset        # 混合比例，offset=4时mix=0.6，仍保留一定颜色
    color = base * (1 - mix) + white * mix
    return color

def plot_combined_all(velocities, accelerations, attention_weights, joints,
                      save_path_stem, crop_start, normalize_attn):
    """
    生成包含所有关节的速度（上）、加速度（中）和注意力热力图（下）的组合图。
    """
    T = velocities.shape[1]
    # 裁剪时间轴
    if T > crop_start:
        vel_crop = velocities[:, crop_start:]
        acc_crop = accelerations[:, crop_start:]
        attn_crop = attention_weights[:, crop_start:]
    else:
        vel_crop = velocities
        acc_crop = accelerations
        attn_crop = attention_weights

    if normalize_attn:
        attn_crop = normalize_minmax(attn_crop, axis=1)

    time = np.arange(vel_crop.shape[1])

    fig, axes = plt.subplots(3, 1, figsize=(FIGURE_WIDTH, FIGURE_HEIGHT),
                             sharex=True, gridspec_kw={'height_ratios': HEIGHT_RATIOS})
    ax_vel, ax_acc, ax_attn = axes

    # ----- 速度子图：绘制所有关节曲线 -----
    for i, joint in enumerate(joints):
        color = get_joint_color(i)
        ax_vel.plot(time, vel_crop[joint], linewidth=LINE_WIDTH,
                    color=color, label=f'J{joint}' if SHOW_LEGEND else "")
    #ax_vel.set_ylabel('Velocity (rad/s)')
    ax_vel.set_title('Joint Angular Velocity (rad/s)')
    ax_vel.grid(True, alpha=0.3)
    if SHOW_LEGEND:
        ax_vel.legend(loc='upper right', ncol=LEGEND_NCOL, framealpha=0.8)

    # ----- 加速度子图：绘制所有关节曲线（颜色与速度子图一致）-----
    for i, joint in enumerate(joints):
        color = get_joint_color(i)
        ax_acc.plot(time, acc_crop[joint], linewidth=LINE_WIDTH,
                    color=color, label=f'J{joint}' if SHOW_LEGEND else "")
    #ax_acc.set_ylabel('Acceleration (rad/s²)')
    ax_acc.set_title('Joint Angular Acceleration (rad/s²)')
    ax_acc.grid(True, alpha=0.3)
    if SHOW_LEGEND:
        ax_acc.legend(loc='upper right', ncol=LEGEND_NCOL, framealpha=0.8)

    # ----- 注意力热力图子图 -----
    im = ax_attn.imshow(attn_crop, aspect='auto', cmap='viridis', origin='lower')
    ax_attn.set_xlabel('Time step')
    ax_attn.set_ylabel('Feature Channel')
    attn_title = 'Attention Weights Heatmap' + (' (normalized)' if normalize_attn else '')
    ax_attn.set_title(attn_title)

    # 颜色条
    divider = make_axes_locatable(ax_attn)
    cax = divider.append_axes("right", size="5%", pad=0.05)
    cbar = fig.colorbar(im, cax=cax)
    cbar.set_label('Weight')

    plt.tight_layout()

    # 保存 PNG 和 SVG
    for ext in ['.png', '.svg']:
        save_path = save_path_stem.with_suffix(ext)
        plt.savefig(save_path, format=ext[1:], dpi=DPI if ext == '.png' else None)
        print(f"Saved combined figure: {save_path}")

    plt.close(fig)

def main():
    set_style()

    for dataset in ['val', 'test']:
        for batch_dir in RESULTS_ROOT.glob(f"{dataset}_batch_*"):
            if not batch_dir.is_dir():
                continue
            print(f"\nProcessing {batch_dir}")

            fig_dir = batch_dir / "combined_figures"
            fig_dir.mkdir(exist_ok=True)

            try:
                velocities = np.load(batch_dir / "velocities.npy")      # shape: (num_joints, T)
                accelerations = np.load(batch_dir / "accelerations.npy")
                attention_weights = np.load(batch_dir / "attention_weights.npy")
            except FileNotFoundError as e:
                print(f"Missing file: {e}, skipping")
                continue

            # 检查关节数量是否足够
            num_joints = velocities.shape[0]
            if num_joints < max(JOINTS) + 1:
                print(f"Warning: velocities has only {num_joints} joints, but requested up to {max(JOINTS)}. Skipping batch.")
                continue

            # 生成一张组合图（包含所有20个关节）
            save_stem = fig_dir / "all_joints_combined"
            plot_combined_all(velocities, accelerations, attention_weights,
                              JOINTS, save_stem, CROP_START, NORMALIZE_ATTN)

            print(f"All figures saved to {fig_dir}")

if __name__ == "__main__":
    main()