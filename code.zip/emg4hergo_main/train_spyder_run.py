#train_spyder_run.py

"""
EMG2Pose训练脚本 - 主文件
包含训练逻辑，调用独立的绘图和数据导出模块
优化版：延迟数据导出，提升训练速度
新增：超参数和数据集信息导出功能
新增：损失函数趋势图
"""
import torch.nn.functional as F
import logging
import pprint
import os
import pandas as pd
import numpy as np
from collections.abc import Callable, Sequence
from pathlib import Path
from typing import Any, List, Dict, Tuple
import datetime

import hydra
import pytorch_lightning as pl
import torch
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from emg2pose import transforms

from emg2pose.lightning import Emg2PoseModule
from emg2pose.transforms import Transform
from hydra.utils import instantiate
from omegaconf import DictConfig, ListConfig, OmegaConf

# 导入绘图和数据导出模块
try:
    from plots_Patch.plot_functions import (
        EnhancedTrainingVisualizer, 
        analyze_predictions, 
        plot_prediction_vs_actual,
        JOINT_NAMES
    )
    print("✅ Successfully imported plotting modules")
except ImportError as e:
    print(f"❌ Failed to import plotting modules: {e}")
    print("   Please make sure 'plots_Patch' directory exists with plot_functions.py")
    raise

# 导入损失绘图模块
try:
    from plots_Patch.loss_plot import LossPlotter
    print("✅ Successfully imported loss plotting module")
except ImportError as e:
    print(f"❌ Failed to import loss plotting module: {e}")
    print("   Creating simple LossPlotter as fallback...")
    # 创建简单的损失绘图器作为备用
    class LossPlotter:
        def __init__(self, save_dir=None):
            self.save_dir = save_dir
            self.training_history = {
                'train_loss': [], 'val_loss': [], 'val_mae': [], 
                'val_r2': [], 'val_mse': [], 'val_rmse': [], 'epochs': []
            }
        def log_losses(self, **kwargs): 
            epoch = kwargs.get('epoch', 0)
            if epoch not in self.training_history['epochs']:
                self.training_history['epochs'].append(epoch)
            for key in ['train_loss', 'val_loss', 'val_mae', 'val_r2', 'val_mse', 'val_rmse']:
                if key in kwargs and kwargs[key] is not None:
                    self.training_history[key].append(kwargs[key])
        def plot_loss_trends(self, model_name="model", figsize=(15, 10)):
            print(f"⚠️ Loss plotting not available. Using fallback.")
            return None
        def save_loss_history(self, model_name="model"):
            print(f"⚠️ Loss history saving not available. Using fallback.")
            return None

# Set base directory
BASE_DIR = Path(r"D:\ComputeData\PoseEstimationModels\emg2pose-main\emg2pose")
RESULTS_DIR = BASE_DIR / "training_results"

print(f"📁 Results will be saved to: {RESULTS_DIR}")

log = logging.getLogger(__name__)

def export_hyperparameters_and_data_info(config, datamodule, save_dir, model_name, window_params=None):
    """
    导出超参数、数据集信息和滑动窗口参数到txt文件
    
    参数:
        config: 配置对象
        datamodule: 数据模块
        save_dir: 保存目录
        model_name: 模型名称
        window_params: 滑动窗口参数字典，包含window_size和step
    """
    print("\n📋 EXPORTING HYPERPARAMETERS AND DATA INFO")
    print("=" * 50)
    
    # 创建文件路径
    file_path = save_dir / f"HyperparametersDatas_{model_name}.txt"
    
    try:
        # 尝试设置数据模块以获取数据集信息
        try:
            datamodule.setup()
            setup_success = True
        except Exception as e:
            print(f"⚠️ Warning: Could not setup datamodule: {e}")
            setup_success = False
        
        # 获取数据集维度信息
        dataset_info = {
            "training_set": None,
            "validation_set": None,
            "test_set": None
        }
        
        if setup_success:
            # 获取训练集维度
            try:
                train_dataset = datamodule.train_dataset
                if hasattr(train_dataset, '__len__'):
                    # 采样一个训练样本
                    train_sample = train_dataset[0] if len(train_dataset) > 0 else None
                    if train_sample is not None:
                        # 获取EMG和关节角度的维度
                        emg_shape = train_sample['emg'].shape if 'emg' in train_sample else "N/A"
                        joints_shape = train_sample['joint_angles'].shape if 'joint_angles' in train_sample else "N/A"
                        dataset_info["training_set"] = {
                            "num_samples": len(train_dataset),
                            "emg_shape": emg_shape,
                            "joint_angles_shape": joints_shape
                        }
            except Exception as e:
                print(f"⚠️ Warning: Could not get training set dimensions: {e}")
        
        # 获取滑动窗口信息
        window_info = {
            "window_size": "N/A",
            "step": "N/A",
            "window_type": "N/A"
        }
        
        # 尝试从配置中提取窗口信息
        try:
            # 检查transforms配置中是否有窗口参数
            if hasattr(config, 'transforms'):
                # 检查train transforms
                for transform in config.transforms.train:
                    if 'window' in str(transform).lower() or 'window' in str(transform.get('_target_', '')).lower():
                        # 尝试提取窗口大小和步长
                        if hasattr(transform, 'window_size'):
                            window_info["window_size"] = transform.window_size
                        elif 'window_size' in transform:
                            window_info["window_size"] = transform.window_size
                        
                        if hasattr(transform, 'step'):
                            window_info["step"] = transform.step
                        elif 'step' in transform:
                            window_info["step"] = transform.step
                        
                        window_info["window_type"] = str(transform.get('_target_', 'Unknown')).split('.')[-1]
                        break
        except Exception as e:
            print(f"⚠️ Warning: Could not extract window info from config: {e}")
        
        # 如果提供了窗口参数，使用它们
        if window_params:
            window_info.update(window_params)
        
        # 获取批处理维度
        batch_info = {}
        try:
            # 采样一个批次
            train_loader = datamodule.train_dataloader()
            batch = next(iter(train_loader))
            
            batch_info = {
                "batch_size": config.batch_size,
                "emg_batch_shape": batch['emg'].shape if 'emg' in batch else "N/A",
                "joint_angles_batch_shape": batch['joint_angles'].shape if 'joint_angles' in batch else "N/A",
                "no_ik_failure_shape": batch['no_ik_failure'].shape if 'no_ik_failure' in batch else "N/A"
            }
        except Exception as e:
            print(f"⚠️ Warning: Could not get batch dimensions: {e}")
        
        # 创建超参数和数据信息字符串
        info_str = "=" * 70 + "\n"
        info_str += "EMG2POSE MODEL - HYPERPARAMETERS AND DATA INFORMATION\n"
        info_str += "=" * 70 + "\n\n"
        
        # 基本信息
        info_str += "1. BASIC INFORMATION\n"
        info_str += "-" * 40 + "\n"
        info_str += f"Model Name: {model_name}\n"
        info_str += f"Export Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        info_str += f"Results Directory: {save_dir}\n"
        
        # 模型超参数
        info_str += "\n\n2. MODEL HYPERPARAMETERS\n"
        info_str += "-" * 40 + "\n"
        
        try:
            # 提取模型配置
            if hasattr(config, 'pose_module'):
                pose_module = config.pose_module
                info_str += f"Model Type: {pose_module.get('_target_', 'Unknown')}\n"
                
                # 添加模型特定参数
                for key, value in pose_module.items():
                    if key != '_target_':
                        info_str += f"{key}: {value}\n"
        except:
            info_str += "Model hyperparameters: Could not extract\n"
        
        # 优化器和学习率
        info_str += "\nOptimizer Configuration:\n"
        try:
            if hasattr(config, 'optimizer'):
                optimizer = config.optimizer
                info_str += f"Optimizer Type: {optimizer.get('_target_', 'Unknown')}\n"
                for key, value in optimizer.items():
                    if key not in ['_target_', '_partial_']:
                        info_str += f"{key}: {value}\n"
        except:
            info_str += "Optimizer: Could not extract\n"
        
        # 学习率调度器
        info_str += "\nLearning Rate Scheduler:\n"
        try:
            if hasattr(config, 'lr_scheduler'):
                scheduler = config.lr_scheduler
                if scheduler is not None:
                    info_str += f"Scheduler Type: {scheduler.get('_target_', 'None')}\n"
                    for key, value in scheduler.items():
                        if key not in ['_target_', '_partial_']:
                            info_str += f"{key}: {value}\n"
                else:
                    info_str += "Scheduler: None\n"
        except:
            info_str += "Scheduler: Could not extract\n"
        
        # 训练参数
        info_str += "\nTraining Parameters:\n"
        info_str += f"Batch Size: {config.batch_size}\n"
        info_str += f"Number of Workers: {config.num_workers}\n"
        if hasattr(config, 'seed'):
            info_str += f"Random Seed: {config.seed}\n"
        if hasattr(config, 'provide_initial_pos'):
            info_str += f"Provide Initial Position: {config.provide_initial_pos}\n"
        if hasattr(config, 'loss_weights'):
            info_str += f"Loss Weights: {config.loss_weights}\n"
        
        # 滑动窗口信息
        info_str += "\n\n3. SLIDING WINDOW CONFIGURATION\n"
        info_str += "-" * 40 + "\n"
        info_str += f"Window Type: {window_info['window_type']}\n"
        info_str += f"Window Size: {window_info['window_size']}\n"
        info_str += f"Step/Stride: {window_info['step']}\n"
        
        # 数据集维度
        info_str += "\n\n4. DATASET DIMENSIONS\n"
        info_str += "-" * 40 + "\n"
        
        if setup_success:
            # 训练集
            if dataset_info["training_set"]:
                info_str += "Training Set:\n"
                info_str += f"  Number of samples/windows: {dataset_info['training_set']['num_samples']}\n"
                info_str += f"  EMG shape per sample: {dataset_info['training_set']['emg_shape']}\n"
                info_str += f"  Joint angles shape per sample: {dataset_info['training_set']['joint_angles_shape']}\n"
            else:
                info_str += "Training Set: Not available\n"
        else:
            info_str += "Training Set: Could not setup datamodule to get dimensions\n"
        
        # 数据分割信息
        info_str += "\n\n5. DATA SPLIT INFORMATION\n"
        info_str += "-" * 40 + "\n"
        try:
            if hasattr(config, 'data_split'):
                splits = instantiate(config.data_split)
                info_str += f"Training sessions: {len(splits['train'])}\n"
                info_str += f"Validation sessions: {len(splits['val'])}\n"
                info_str += f"Test sessions: {len(splits['test'])}\n"
                info_str += f"Data location: {config.data_location}\n"
        except Exception as e:
            info_str += f"Data split: Error extracting - {e}\n"
        
        # 变换信息
        info_str += "\n\n6. DATA TRANSFORMS\n"
        info_str += "-" * 40 + "\n"
        try:
            if hasattr(config, 'transforms'):
                info_str += "Training transforms:\n"
                for i, transform in enumerate(config.transforms.train):
                    info_str += f"  {i+1}. {transform.get('_target_', 'Unknown')}\n"
                
                info_str += "\nValidation transforms:\n"
                for i, transform in enumerate(config.transforms.val):
                    info_str += f"  {i+1}. {transform.get('_target_', 'Unknown')}\n"
                
                info_str += "\nTest transforms:\n"
                for i, transform in enumerate(config.transforms.test):
                    info_str += f"  {i+1}. {transform.get('_target_', 'Unknown')}\n"
        except:
            info_str += "Transforms: Could not extract\n"
        
        info_str += "\n" + "=" * 70 + "\n"
        info_str += "END OF HYPERPARAMETERS AND DATA INFORMATION\n"
        info_str += "=" * 70
        
        # 写入文件
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(info_str)
        
        print(f"✅ Hyperparameters and data info exported to: {file_path}")
        print("=" * 50)
        
        # 同时在控制台打印摘要
        print("\n📊 DATA DIMENSIONS SUMMARY:")
        print("-" * 30)
        if dataset_info["training_set"]:
            print(f"Training set: {dataset_info['training_set']['num_samples']} samples")
        print(f"Sliding window: size={window_info['window_size']}, step={window_info['step']}")
        
        return file_path
        
    except Exception as e:
        print(f"❌ Error exporting hyperparameters and data info: {e}")
        import traceback
        traceback.print_exc()
        return None

def make_data_module(config: DictConfig):
    """从实验配置创建数据模块，带有增强的日志记录和错误处理"""
    
    print("=" * 50)
    print("DATA MODULE CONFIGURATION")
    print("=" * 50)

    # 数据集会话路径，带有文件存在性检查
    def _full_paths(root: str, dataset: ListConfig) -> list[Path]:
        sessions = dataset
        paths = []
        missing_files = []
        
        for session in sessions:
            path = Path(root).expanduser().joinpath(f"{session}.hdf5")
            if path.exists():
                paths.append(path)
            else:
                missing_files.append(path)
        
        if missing_files:
            print(f"⚠️  Missing files: {len(missing_files)}")
            for missing in missing_files[:5]:
                print(f"   - {missing}")
            if len(missing_files) > 5:
                print(f"   ... and {len(missing_files) - 5} more")
            
        return paths

    splits = instantiate(config.data_split)
    
    if hasattr(config.data_split, '_target_'):
        print(f"Using data split: {config.data_split._target_}")
    else:
        print("Using data split: (direct configuration)")
    
    train_sessions = _full_paths(config.data_location, splits["train"])
    val_sessions = _full_paths(config.data_location, splits["val"])
    test_sessions = _full_paths(config.data_location, splits["test"])
    
    if not train_sessions:
        raise ValueError("❌ No training sessions found! Check your data_split configuration and data files.")
    
    print(f"✅ Training sessions: {len(train_sessions)}")
    for session in train_sessions:
        print(f"  - {session}")
    
    print(f"✅ Validation sessions: {len(val_sessions)}")
    for session in val_sessions:
        print(f"  - {session}")
    
    print(f"✅ Test sessions: {len(test_sessions)}")
    for session in test_sessions:
        print(f"  - {session}")
        
    print(f"Data location: {config.data_location}")
    print(f"Batch size: {config.batch_size}")
    print(f"Number of workers: {config.num_workers}")

    datamodule = instantiate(
        config.datamodule,
        batch_size=config.batch_size,
        num_workers=config.num_workers,
        train_sessions=train_sessions,
        val_sessions=val_sessions,
        test_sessions=test_sessions,
        skip_ik_failures=config.datamodule.get("skip_ik_failures", False),
    )

    # 实例化变换
    def _build_transform(configs: Sequence[DictConfig]) -> Transform[Any, Any]:
        return transforms.Compose([instantiate(cfg) for cfg in configs])

    datamodule.train_transforms = _build_transform(config.transforms.train)
    datamodule.val_transforms = _build_transform(config.transforms.val)
    datamodule.test_transforms = _build_transform(config.transforms.test)
    
    print("✅ Data transforms configured successfully")
    print("=" * 50)

    return datamodule

def make_lightning_module(config: DictConfig):
    """从实验配置创建lightning模块，带有增强的日志记录"""
    
    print("=" * 50)
    print("MODEL CONFIGURATION")
    print("=" * 50)
    print(f"Network configuration: {config.pose_module}")
    print(f"Optimizer: {config.optimizer}")
    print(f"Learning rate scheduler: {config.lr_scheduler}")
    print(f"Provide initial position: {config.provide_initial_pos}")
    print(f"Loss weights: {config.loss_weights}")
    print("=" * 50)
    
    return Emg2PoseModule(
        network_conf=config.pose_module,
        optimizer_conf=config.optimizer,
        lr_scheduler_conf=config.lr_scheduler,
        provide_initial_pos=config.provide_initial_pos,
        loss_weights=config.loss_weights,
    )

class DataStorage:
    """数据存储类，用于延迟导出数据"""
    
    def __init__(self):
        self.clear()
        
    def clear(self):
        """清空所有存储的数据"""
        self.val_predictions = []
        self.val_targets = []
        self.val_no_ik_failure = []
        self.val_emg_data = []
        self.val_batches = []
        
        self.test_predictions = []
        self.test_targets = []
        self.test_no_ik_failure = []
        self.test_emg_data = []
        self.test_batches = []
        
        self.val_metrics_history = []
        self.test_metrics_history = []
        
    def add_validation_data(self, preds, targets, no_ik_failure, emg_data, batch, max_batches=1):
        """添加验证数据"""
        # 限制存储的批次数量，避免内存占用
        if len(self.val_predictions) < max_batches:
            self.val_predictions.append(preds.detach().cpu().numpy())
            self.val_targets.append(targets.detach().cpu().numpy())
            self.val_no_ik_failure.append(no_ik_failure.detach().cpu().numpy())
            if emg_data is not None:
                self.val_emg_data.append(emg_data.detach().cpu().numpy())
            self.val_batches.append(batch)
                
    def add_test_data(self, preds, targets, no_ik_failure, emg_data, batch, max_batches=1):
        """添加测试数据"""
        # 限制存储的批次数量
        if len(self.test_predictions) < max_batches:
            self.test_predictions.append(preds.detach().cpu().numpy())
            self.test_targets.append(targets.detach().cpu().numpy())
            self.test_no_ik_failure.append(no_ik_failure.detach().cpu().numpy())
            if emg_data is not None:
                self.test_emg_data.append(emg_data.detach().cpu().numpy())
            self.test_batches.append(batch)
                
    def add_validation_metrics(self, metrics):
        """添加验证指标"""
        self.val_metrics_history.append(metrics)
        
    def add_test_metrics(self, metrics):
        """添加测试指标"""
        self.test_metrics_history.append(metrics)













class EnhancedEmg2PoseModule(Emg2PoseModule):
    """增强版本，带有更好的日志记录和可视化，延迟数据导出"""
    
    def __init__(self, *args, save_dir=None, config=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.save_dir = save_dir
        self.config = config
        self.visualizer = EnhancedTrainingVisualizer(config, save_dir) if config else EnhancedTrainingVisualizer({}, save_dir)
        self.data_storage = DataStorage()
        self.validation_outputs = []  # 用于存储验证步骤的输出
        self.test_outputs = []  # 用于存储测试步骤的输出
        self.loss_plotter = LossPlotter(save_dir)
        self.should_export_data = False  # 是否应该导出数据
        
        # 训练状态跟踪 - 使用私有属性避免冲突
        self._train_epoch = 0
        self.train_losses = []
        self.val_losses = []
        self.val_maes = []
        self.val_r2s = []
        

    def _save_attention_intermediates(self, batch, batch_idx, dataset_type='val'):
        """保存注意力中间变量到 npy 文件"""
        if not hasattr(self.model, 'return_intermediates'):
            print("⚠️ Model does not support return_intermediates, skipping.")
            return
        original_flag = self.model.return_intermediates
        self.model.return_intermediates = True
    
        try:
            emg = batch["emg"]
            joint_angles = batch["joint_angles"]
            initial_pos = joint_angles[..., self.model.left_context]
            if not self.provide_initial_pos:
                initial_pos = torch.zeros_like(initial_pos)
    
            with torch.no_grad():
                outputs = self.model._predict_pose(emg, initial_pos)
                if not isinstance(outputs, tuple) or len(outputs) != 4:
                    print(f"❌ Unexpected output: {type(outputs)}")
                    return
                positions, velocities, accelerations, attn_weights = outputs
    
            # 时间对齐
            start = self.model.left_context
            stop = None if self.model.right_context == 0 else -self.model.right_context
            targets = joint_angles[..., slice(start, stop)]
            no_ik_failure = batch["no_ik_failure"][..., slice(start, stop)]
            n_time = targets.shape[-1]
    
            positions = self.model.align_predictions(positions, n_time)
            velocities = F.interpolate(velocities, size=n_time, mode='linear')
            accelerations = F.interpolate(accelerations, size=n_time, mode='linear')
            attn_weights = F.interpolate(attn_weights, size=n_time, mode='linear')
    
            save_dir = self.save_dir / f"{dataset_type}_batch_{batch_idx}"
            save_dir.mkdir(parents=True, exist_ok=True)
    
            np.save(save_dir / "positions.npy", positions[0].cpu().numpy())
            np.save(save_dir / "targets.npy", targets[0].cpu().numpy())
            np.save(save_dir / "velocities.npy", velocities[0].cpu().numpy())
            np.save(save_dir / "accelerations.npy", accelerations[0].cpu().numpy())
            np.save(save_dir / "attention_weights.npy", attn_weights[0].cpu().numpy())
            np.save(save_dir / "no_ik_failure.npy", no_ik_failure[0].cpu().numpy())
            print(f"✅ Saved to {save_dir}")
    
        except Exception as e:
            print(f"❌ Error saving: {e}")
            import traceback
            traceback.print_exc()
        finally:
            self.model.return_intermediates = original_flag

    
    def get_model_name(self):
        """从配置中提取模型名称"""
        if not self.config:
            return "unknown_model"
        
        try:
            # 从配置中获取模型名称
            pose_module = self.config.get('pose_module', {})
            if hasattr(pose_module, '_target_'):
                model_name = pose_module._target_.split('.')[-1]
            elif isinstance(pose_module, dict) and '_target_' in pose_module:
                model_name = pose_module['_target_'].split('.')[-1]
            else:
                # 尝试从配置字符串中提取
                config_str = str(pose_module)
                for model in ['tcn', 'transformer', 'cnn_lstm', 'lstm', 'gru', 'mlp']:
                    if model in config_str.lower():
                        model_name = model
                        break
                else:
                    model_name = "custom_model"
            
            # 清理模型名称
            model_name = model_name.replace('_pose', '').replace('_module', '').replace('_net', '')
            return model_name
        except:
            return "unknown_model"
    
    def extract_window_params(self):
        """从配置中提取滑动窗口参数"""
        window_params = {
            "window_size": "N/A",
            "step": "N/A",
            "window_type": "N/A"
        }
        
        try:
            if self.config and hasattr(self.config, 'transforms'):
                # 检查训练变换
                for transform in self.config.transforms.train:
                    if 'window' in str(transform).lower():
                        # 尝试提取窗口大小和步长
                        if hasattr(transform, 'window_size'):
                            window_params["window_size"] = transform.window_size
                        elif 'window_size' in transform:
                            window_params["window_size"] = transform['window_size']
                        
                        if hasattr(transform, 'step'):
                            window_params["step"] = transform.step
                        elif 'step' in transform:
                            window_params["step"] = transform['step']
                        
                        # 获取变换类型
                        if hasattr(transform, '_target_'):
                            window_params["window_type"] = transform._target_.split('.')[-1]
                        break
        except Exception as e:
            print(f"⚠️ Warning: Could not extract window parameters: {e}")
        
        return window_params
    

        
    def training_step(self, batch, batch_idx):
        # 调用父类（Emg2PoseModule）的 training_step 获取 loss
        loss = super().training_step(batch, batch_idx)
        
        # ========== 调试信息（只打印前几个 step） ==========
        if batch_idx < 5:  # 只打印前5个batch
            print(f"\n[DEBUG] Step {self.global_step}, batch {batch_idx}")
            print(f"  loss = {loss.item():.6f}")
            
            # 检查有效样本数（no_ik_failure 掩码）
            mask = batch['no_ik_failure']
            valid_samples = mask.sum().item()
            total_samples = mask.numel()
            print(f"  Valid IK samples: {valid_samples} / {total_samples}")
            
            # 检查梯度范数
            total_norm = 0.0
            for p in self.parameters():
                if p.grad is not None:
                    total_norm += p.grad.norm().item() ** 2
            grad_norm = total_norm ** 0.5
            print(f"  Gradient norm: {grad_norm:.6f}")
            
            # 检查学习率
            lr = self.trainer.optimizers[0].param_groups[0]['lr']
            print(f"  Learning rate: {lr:.6f}")
            
            # 检查模型输出的均值和方差（可选）
            with torch.no_grad():
                # 临时前向传播获取预测（注意不要重复计算）
                batch["no_ik_failure"] = self.update_ik_failure_mask(batch["no_ik_failure"])
                preds, targets, _ = self.forward(batch)
                print(f"  pred mean = {preds.mean().item():.4f}, std = {preds.std().item():.4f}")
        
        return loss
        
        
        
        
        return loss
    
    def on_train_epoch_end11(self):
        """在epoch结束时记录训练指标"""
        # 获取此epoch的平均训练损失
        train_loss = self.trainer.callback_metrics.get('train_loss', None)
        if train_loss is not None:
            self.train_losses.append(float(train_loss))
            self._train_epoch = len(self.train_losses)
            
            # 更新损失绘图器
            self.loss_plotter.log_losses(
                epoch=self._train_epoch,
                train_loss=float(train_loss)
            )
    
    def on_train_epoch_end(self):
        """在每个训练 epoch 结束时，记录 epoch 平均训练损失"""
        # 从 Lightning 的 callback_metrics 中获取已经计算好的 epoch 平均损失
        train_loss_epoch = self.trainer.callback_metrics.get('train_loss_epoch')
        if train_loss_epoch is None:
            # 兼容不同版本，有时 key 是 'train_loss'
            train_loss_epoch = self.trainer.callback_metrics.get('train_loss')
        if train_loss_epoch is not None:
            # 显式记录 epoch 级别的损失，确保写入 CSV 的一行
            self.log('train_loss_epoch', train_loss_epoch, sync_dist=True, on_epoch=True, on_step=False)
    
    def on_validation_epoch_end(self):
        """在每个验证 epoch 结束时，记录 epoch 平均验证损失"""
        val_loss_epoch = self.trainer.callback_metrics.get('val_loss_epoch')
        if val_loss_epoch is None:
            val_loss_epoch = self.trainer.callback_metrics.get('val_loss')
        if val_loss_epoch is not None:
            self.log('val_loss_epoch', val_loss_epoch, sync_dist=True, on_epoch=True, on_step=False)

    def on_train_epoch_end22(self):
        # 获取当前 epoch 的平均训练损失（Lightning 已自动计算）
        train_loss_epoch = self.trainer.callback_metrics.get('train_loss_epoch', None)
        if train_loss_epoch is None:
            train_loss_epoch = self.trainer.callback_metrics.get('train_loss', None)
        
        if train_loss_epoch is not None:
            # 显式记录 epoch 级别的训练损失，确保 CSVLogger 写入
            self.log('train_loss_epoch', train_loss_epoch, sync_dist=True, on_epoch=True, on_step=False)
            # 同时保存到自定义列表（可选）
            self.train_losses.append(float(train_loss_epoch))
            self._train_epoch = len(self.train_losses)
            self.loss_plotter.log_losses(epoch=self._train_epoch, train_loss=float(train_loss_epoch))
    
    def on_validation_epoch_end22(self):
        # 获取当前 epoch 的平均验证损失
        val_loss_epoch = self.trainer.callback_metrics.get('val_loss_epoch', None)
        if val_loss_epoch is None:
            val_loss_epoch = self.trainer.callback_metrics.get('val_loss', None)
        
        if val_loss_epoch is not None:
            self.log('val_loss_epoch', val_loss_epoch, sync_dist=True, on_epoch=True, on_step=False)
            self.val_losses.append(float(val_loss_epoch))
            self.loss_plotter.log_losses(epoch=self.current_epoch, val_loss=float(val_loss_epoch))
            
            # 可选：计算其他指标
            if self.validation_outputs:
                output = self.validation_outputs[0]
                preds = output['preds']
                targets = output['targets']
                no_ik_failure = output['no_ik_failure']
                val_metrics = self.calculate_metrics(preds, targets, no_ik_failure)
                self.loss_plotter.log_losses(
                    epoch=self.current_epoch,
                    val_mae=val_metrics.get('mae'),
                    val_r2=val_metrics.get('r2'),
                    val_mse=val_metrics.get('mse'),
                    val_rmse=val_metrics.get('rmse')
                )
                self.validation_outputs.clear()  # 清空以释放内存
    
    def _save_loss_to_csv(self, epoch, train_loss=None, val_loss=None):
        """手动保存损失到 CSV 文件"""
        csv_path = self.save_dir / f"loss_history_{self.get_model_name()}_manual.csv"
        file_exists = csv_path.exists()
        with open(csv_path, 'a') as f:
            import csv
            writer = csv.writer(f)
            if not file_exists:
                writer.writerow(['epoch', 'train_loss', 'val_loss'])
            writer.writerow([epoch, train_loss if train_loss is not None else '', val_loss if val_loss is not None else ''])
    
    
















    def validation_step(self, batch, batch_idx):
        # 1. 对指定批次保存注意力中间变量（例如第0、9、99个batch）
        if self.should_export_data and batch_idx in [0, 9, 99]:
            self._save_attention_intermediates(batch, batch_idx, dataset_type='val')
        
        # 2. 原有的第一个批次数据收集逻辑（用于后续绘图和指标计算）
        if batch_idx == 0:  # 只收集第一个批次
            batch["no_ik_failure"] = self.update_ik_failure_mask(batch["no_ik_failure"])
            preds, targets, no_ik_failure = self.forward(batch)
            
            if self.should_export_data:
                emg_data = batch.get('emg', None)
                self.data_storage.add_validation_data(
                    preds, targets, no_ik_failure, emg_data, batch, max_batches=1
                )
            
            self.validation_outputs.append({
                'preds': preds,
                'targets': targets,
                'no_ik_failure': no_ik_failure,
                'batch': batch
            })
        
        # 3. 调用父类方法计算loss（必须保留）
        loss = super().validation_step(batch, batch_idx)
        
        
        
        
        return loss
    
    
    
    
    
    
    
    
    
    
    def on_validation_epoch_end111(self):
        """在验证epoch结束时进行分析和可视化"""
        # 处理验证输出
        if self.validation_outputs:
            output = self.validation_outputs[0]
            preds = output['preds']
            targets = output['targets']
            no_ik_failure = output['no_ik_failure']
            
            # 计算指标
            val_metrics = self.calculate_metrics(preds, targets, no_ik_failure)
            
            # 记录验证损失
            val_loss = self.trainer.callback_metrics.get('val_loss', torch.tensor(0.0))
            if val_loss is not None:
                self.val_losses.append(float(val_loss))
            
            # 更新损失绘图器
            self.loss_plotter.log_losses(
                epoch=self._train_epoch,
                val_loss=float(val_loss) if val_loss is not None else None,
                val_mae=val_metrics.get('mae', None),
                val_r2=val_metrics.get('r2', None),
                val_mse=val_metrics.get('mse', None),
                val_rmse=val_metrics.get('rmse', None)
            )
            
            # 存储验证指标
            self.data_storage.add_validation_metrics(val_metrics)
            
            # 清理输出
            self.validation_outputs.clear()
    

    
    def test_step(self, batch, batch_idx):
        # 1. 保存指定批次的注意力中间变量（例如第0、9、99个batch）
        if self.should_export_data and batch_idx in [0, 9, 99]:
            self._save_attention_intermediates(batch, batch_idx, dataset_type='test')
        
        # 2. 原有的第一个批次数据收集逻辑（用于导出CSV和图表）
        if self.should_export_data and batch_idx == 0:  # 只收集第一个批次
            batch["no_ik_failure"] = self.update_ik_failure_mask(batch["no_ik_failure"])
            preds, targets, no_ik_failure = self.forward(batch)
            
            # 存储数据用于最后导出
            emg_data = batch.get('emg', None)
            self.data_storage.add_test_data(
                preds, targets, no_ik_failure, emg_data, batch, max_batches=1
            )
            
            # 存储输出用于分析
            self.test_outputs.append({
                'preds': preds,
                'targets': targets,
                'no_ik_failure': no_ik_failure,
                'batch': batch
            })
        
        # 3. 调用父类方法计算loss和指标（必须保留）
        loss = super().test_step(batch, batch_idx)
        return loss
        
    
    
    def on_test_epoch_end(self):
        """在测试epoch结束时计算指标"""
        if self.test_outputs and self.should_export_data:
            output = self.test_outputs[0]
            preds = output['preds']
            targets = output['targets']
            no_ik_failure = output['no_ik_failure']
            
            # 计算测试指标
            test_metrics = self.calculate_metrics(preds, targets, no_ik_failure)
            self.data_storage.add_test_metrics(test_metrics)
            
            self.test_outputs.clear()
    
    def calculate_metrics(self, preds, targets, no_ik_failure):
        """计算预测指标"""
        # 检查掩码形状并适当调整
        if len(no_ik_failure.shape) == 2 and len(preds.shape) == 3:
            # 掩码形状: [batch, time], 预测值形状: [batch, joints, time]
            # 扩展掩码维度以匹配预测值和目标值的形状 [batch, joints, time]
            # no_ik_failure 形状: [batch, time] -> 扩展为 [batch, 1, time]
            mask_expanded = no_ik_failure.unsqueeze(1)  # 现在形状为 [batch, 1, time]
            # 将掩码广播到与预测值相同的形状
            mask_broadcasted = mask_expanded.expand_as(preds)  # 现在形状为 [batch, joints, time]
            
            # 应用IK失败掩码
            preds_masked = preds[mask_broadcasted]
            targets_masked = targets[mask_broadcasted]
        else:
            # 如果形状已经匹配，直接使用
            preds_masked = preds[no_ik_failure]
            targets_masked = targets[no_ik_failure]
        
        if len(preds_masked) == 0:
            return {}
        
        # 计算指标
        mae = mean_absolute_error(targets_masked.cpu().numpy(), preds_masked.cpu().numpy())
        mse = mean_squared_error(targets_masked.cpu().numpy(), preds_masked.cpu().numpy())
        rmse = np.sqrt(mse)
        
        # 计算R²
        try:
            r2 = r2_score(targets_masked.cpu().numpy(), preds_masked.cpu().numpy())
        except:
            r2 = 0.0
        
        return {
            'mae': mae,
            'mse': mse,
            'rmse': rmse,
            'r2': r2
        }
    
    def set_export_mode(self, export=True):
        """设置是否应该导出数据"""
        self.should_export_data = export
        if export:
            print("📤 Data export mode enabled - will collect and export data after evaluation")
    
    def export_all_data(self):
        """导出所有存储的数据到CSV文件和图像"""
        print("\n📤 EXPORTING ALL DATA TO CSV FILES AND IMAGES")
        print("=" * 50)
        
        model_name = self.get_model_name()
        
        # 1. 绘制损失趋势图
        print(f"\n📈 Plotting loss trends for model: {model_name}")
        self.loss_plotter.plot_loss_trends(model_name)
        self.loss_plotter.save_loss_history(model_name)
        
        # 2. 导出验证数据
        if len(self.data_storage.val_predictions) > 0:
            print(f"\n📊 Exporting validation data for model: {model_name}")
            
            # 获取数据
            preds_np = np.vstack(self.data_storage.val_predictions)
            targets_np = np.vstack(self.data_storage.val_targets)
            no_ik_failure_np = np.vstack(self.data_storage.val_no_ik_failure)
            
            # 转换回torch tensor
            preds = torch.from_numpy(preds_np)
            targets = torch.from_numpy(targets_np)
            no_ik_failure = torch.from_numpy(no_ik_failure_np)
            
            # 分析预测并保存图表
            print("  - Generating validation prediction plots...")
            val_analysis = analyze_predictions(
                preds, targets, no_ik_failure, 
                "val", self.save_dir, model_name
            )
            
            # 绘制预测值与实际值的对比图
            plot_prediction_vs_actual(
                preds, targets, no_ik_failure, 
                "val", self.save_dir, model_name
            )
            
            # 保存关节预测结果CSV
            if len(self.data_storage.val_batches) > 0:
                batch = self.data_storage.val_batches[0]
                hand_side = batch.get('hand_side', "left")
                
                # 导入数据导出函数
                try:
                    from plots_Patch.data_export import save_joint_predictions_csv, save_emg_joint_timeseries_csv
                    print("  - Saving validation joint predictions CSV...")
                    save_joint_predictions_csv(
                        preds, targets, no_ik_failure, 
                        model_name, self.save_dir,
                        hand_side=hand_side,
                        sample_rate=15.0,
                        batch_idx=0,
                        dataset_type="val"
                    )
                except ImportError as e:
                    print(f"⚠️ Could not import data export functions: {e}")
                    print("  Skipping CSV export...")
            
            # 保存EMG和关节时间序列CSV
            if len(self.data_storage.val_emg_data) > 0:
                emg_data_np = np.vstack(self.data_storage.val_emg_data)
                emg_data = torch.from_numpy(emg_data_np)
                
                emg_channels = emg_data.shape[1]
                emg_channel_names = [f"EMG{i+1}" for i in range(emg_channels)]
                
                try:
                    from plots_Patch.data_export import save_emg_joint_timeseries_csv
                    print("  - Saving validation EMG-joint time series CSV...")
                    save_emg_joint_timeseries_csv(
                        emg_data, preds, targets, no_ik_failure,
                        model_name, self.save_dir,
                        hand_side="left",
                        sample_rate=15.0,
                        batch_idx=0,
                        emg_channel_names=emg_channel_names,
                        dataset_type="val"
                    )
                except ImportError as e:
                    print(f"⚠️ Could not import data export functions: {e}")
                    print("  Skipping EMG-joint CSV export...")
        
        # 3. 导出测试数据
        if len(self.data_storage.test_predictions) > 0:
            print(f"\n📊 Exporting test data for model: {model_name}")
            
            # 获取数据
            preds_np = np.vstack(self.data_storage.test_predictions)
            targets_np = np.vstack(self.data_storage.test_targets)
            no_ik_failure_np = np.vstack(self.data_storage.test_no_ik_failure)
            
            # 转换回torch tensor
            preds = torch.from_numpy(preds_np)
            targets = torch.from_numpy(targets_np)
            no_ik_failure = torch.from_numpy(no_ik_failure_np)
            
            # 分析测试预测并保存图表
            print("  - Generating test prediction plots...")
            test_analysis = analyze_predictions(
                preds, targets, no_ik_failure, 
                "test", self.save_dir, model_name
            )
            
            # 绘制测试集的预测值与实际值的对比图
            plot_prediction_vs_actual(
                preds, targets, no_ik_failure, 
                "test", self.save_dir, model_name
            )
            
            # 保存测试集关节预测结果CSV
            if len(self.data_storage.test_batches) > 0:
                batch = self.data_storage.test_batches[0]
                hand_side = batch.get('hand_side', "left")
                
                try:
                    from plots_Patch.data_export import save_joint_predictions_csv
                    print("  - Saving test joint predictions CSV...")
                    save_joint_predictions_csv(
                        preds, targets, no_ik_failure, 
                        model_name, self.save_dir,
                        hand_side=hand_side,
                        sample_rate=15.0,
                        batch_idx=0,
                        dataset_type="test"
                    )
                except ImportError as e:
                    print(f"⚠️ Could not import data export functions: {e}")
                    print("  Skipping test CSV export...")
            
            # 保存测试集EMG和关节时间序列CSV
            if len(self.data_storage.test_emg_data) > 0:
                emg_data_np = np.vstack(self.data_storage.test_emg_data)
                emg_data = torch.from_numpy(emg_data_np)
                
                emg_channels = emg_data.shape[1]
                emg_channel_names = [f"EMG{i+1}" for i in range(emg_channels)]
                
                try:
                    from plots_Patch.data_export import save_emg_joint_timeseries_csv
                    print("  - Saving test EMG-joint time series CSV...")
                    save_emg_joint_timeseries_csv(
                        emg_data, preds, targets, no_ik_failure,
                        model_name, self.save_dir,
                        hand_side="left",
                        sample_rate=15.0,
                        batch_idx=0,
                        emg_channel_names=emg_channel_names,
                        dataset_type="test"
                    )
                except ImportError as e:
                    print(f"⚠️ Could not import data export functions: {e}")
                    print("  Skipping test EMG-joint CSV export...")
        
        print("\n✅ All data exported successfully")
        print("=" * 50)

def get_model_name_from_config(config):
    """从配置中提取模型名称"""
    try:
        pose_module = config.get('pose_module', {})

        if hasattr(pose_module, '_target_'):
            model_name = pose_module._target_.split('.')[-1]
        elif isinstance(pose_module, dict) and '_target_' in pose_module:
            model_name = pose_module['_target_'].split('.')[-1]
        else:
            config_str = str(pose_module)
            for model in ['tcn', 'transformer', 'cnn_lstm', 'lstm', 'gru', 'mlp']:
                if model in config_str.lower():
                    model_name = model
                    break
            else:
                model_name = "custom_model"
        
        model_name = model_name.replace('_pose', '').replace('_module', '').replace('_net', '')
        return model_name
    except Exception as e:
        print(f"Warning: Could not extract model name: {e}")
        return "unknown_model"

def train_enhanced(
    config: DictConfig,
    extra_callbacks: Sequence[Callable] | None = None,
):
    """增强的训练函数，带有更好的可视化和分析，延迟数据导出"""
    
    # 获取模型名称
    model_name = get_model_name_from_config(config)
    

    
    
    
    # 创建结果目录，包含模型名称和时间戳
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    save_dir = RESULTS_DIR / f"{model_name}_{timestamp}"
    save_dir.mkdir(parents=True, exist_ok=True)
    
    print("🚀 STARTING ENHANCED EMG2POSE TRAINING")
    print("=" * 60)
    print(f"📂 Results directory: {save_dir}")
    print(f"🤖 Model: {model_name}")
    print(f"📅 Timestamp: {timestamp}")
    
    log.info(f"\nConfig:\n{OmegaConf.to_yaml(config)}")

    # 确定性种子
    pl.seed_everything(config.seed, workers=True)

    if config.checkpoint is not None:
        log.info(f"Loading from checkpoint {config.checkpoint}")
        module = EnhancedEmg2PoseModule.load_from_checkpoint(
            config.checkpoint,
            save_dir=save_dir,
            config=config
        )
    else:
        log.info("Instantiating Enhanced LightningModule")
        module = EnhancedEmg2PoseModule(
            network_conf=config.pose_module,
            optimizer_conf=config.optimizer,
            lr_scheduler_conf=config.lr_scheduler,
            provide_initial_pos=config.provide_initial_pos,
            loss_weights=config.loss_weights,
            save_dir=save_dir,
            config=config
        )

    log.info("Instantiating LightningDataModule")
    datamodule = make_data_module(config)

    
    # 强制 setup 以获取数据集
    datamodule.setup()
    
    # 打印数据集长度
    train_len = len(datamodule.train_dataset) if hasattr(datamodule, 'train_dataset') else 'N/A'
    val_len = len(datamodule.val_dataset) if hasattr(datamodule, 'val_dataset') else 'N/A'
    test_len = len(datamodule.test_dataset) if hasattr(datamodule, 'test_dataset') else 'N/A'
    
    print(f"1Training samples (windows): {train_len}")
    print(f"Validation samples: {val_len}")
    print(f"Test samples: {test_len}")
    
    # 计算每个 epoch 的 batch 数量
    batch_size = config.batch_size
    train_batches = train_len // batch_size if isinstance(train_len, int) else 'N/A'
    print(f"Training batches per epoch: {train_batches} (batch_size={batch_size})")
    
    # 打印一个样本的形状以确认
    if train_len > 0:
        sample = datamodule.train_dataset[0]
        print(f"Sample EMG shape: {sample['emg'].shape}")
        print(f"Sample joint angles shape: {sample['joint_angles'].shape}")
    print("=" * 40)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # 尝试打印数据维度
    print("\n📊 DATA DIMENSIONS ANALYSIS")
    print("=" * 40)
    try:
        # 不调用datamodule.setup()，让PyTorch Lightning自动处理
        # 只在训练前尝试获取一个批次
        if hasattr(datamodule, 'train_dataloader'):
            sample_loader = datamodule.train_dataloader()
            sample_batch = next(iter(sample_loader))
            
            print(f"EMG input shape: {sample_batch['emg'].shape}")
            print(f"Joint angles shape: {sample_batch['joint_angles'].shape}")
            print(f"Number of EMG channels: {sample_batch['emg'].shape[1]}")
            print(f"Number of joints: {sample_batch['joint_angles'].shape[1]}")
            if len(sample_batch['emg'].shape) > 2:
                print(f"Time steps per window: {sample_batch['emg'].shape[2]}")
            print(f"No IK failure mask shape: {sample_batch['no_ik_failure'].shape}")
        else:
            print("⚠️  Warning: datamodule does not have train_dataloader method")
        print("=" * 40)
    except Exception as e:
        print(f"⚠️  Warning: Could not analyze data dimensions: {e}")
        print("Continuing with training...")

    # 实例化回调
    callback_configs = config.get("callbacks", [])
    callbacks = [instantiate(cfg) for cfg in callback_configs]

    if extra_callbacks is not None:
        callbacks.extend(extra_callbacks)

    trainer = pl.Trainer(
        **config.trainer,
        callbacks=callbacks,
    )

    results = {}
    if config.train:
        print("\n🎯 STARTING TRAINING")
        print("=" * 40)
        
        # 训练前不导出数据
        module.set_export_mode(False)
        
        # 训练
        trainer.fit(module, datamodule)

        # 加载最佳检查点
        checkpoint_callback = trainer.checkpoint_callback
        if checkpoint_callback is None:
            raise RuntimeError("No checkpoint callback found in trainer")
        best_checkpoint_path = checkpoint_callback.best_model_path
        
        # 重新创建模块并加载检查点
        module = EnhancedEmg2PoseModule(
            network_conf=config.pose_module,
            optimizer_conf=config.optimizer,
            lr_scheduler_conf=config.lr_scheduler,
            provide_initial_pos=config.provide_initial_pos,
            loss_weights=config.loss_weights,
            save_dir=save_dir,
            config=config
        )
        
        # 使用非严格模式加载以处理潜在的形状不匹配
        checkpoint = torch.load(best_checkpoint_path)
        module.load_state_dict(checkpoint['state_dict'], strict=False)
        module._train_epoch = trainer.current_epoch
        
        results["best_checkpoint"] = best_checkpoint_path

    if config.eval:
        print("\n📈 RUNNING EVALUATION")
        print("=" * 40)
        
        # 设置导出模式
        module.set_export_mode(True)
        
        # 计算验证集和测试集指标
        module.eval()
        val_metrics = trainer.validate(module, datamodule)
        test_metrics = trainer.test(module, datamodule)

        results["val_metrics"] = val_metrics
        results["test_metrics"] = test_metrics
        
        # 生成综合报告
        try:
            from plots_Patch.data_export import generate_comprehensive_report
            generate_comprehensive_report(config, results, datamodule, save_dir)
        except ImportError as e:
            print(f"⚠️ Could not generate comprehensive report: {e}")
        
        # 导出所有CSV数据和图像
        module.export_all_data()
        
        # 导出超参数和数据集信息
        window_params = module.extract_window_params()
        export_hyperparameters_and_data_info(
            config=config,
            datamodule=datamodule,
            save_dir=save_dir,
            model_name=model_name,
            window_params=window_params
        )
        
        # 使用可视化器绘制训练进度
        module.visualizer.plot_all_metrics_separately()
        module.visualizer.plot_training_progress()

    print("\n✅ TRAINING COMPLETED")
    print("=" * 60)
    print(f"📊 Model: {model_name}")
    print("Results Summary:")
    pprint.pprint(results, sort_dicts=False)
    
    # 打印重要文件位置
    print(f"\n📁 Generated files in: {save_dir}")
    print(f"   - Loss trends: loss_trends_{model_name}.png")
    print(f"   - Loss history: loss_history_{model_name}.csv")
    print(f"   - Loss summary: loss_summary_{model_name}.txt")
    print(f"   - Validation joint performance: val_joint_performance_{model_name}.png")
    print(f"   - Validation prediction vs actual: val_prediction_vs_actual_fig*_{model_name}.png")
    print(f"   - Test joint performance: test_joint_performance_{model_name}.png")
    print(f"   - Test prediction vs actual: test_prediction_vs_actual_fig*_{model_name}.png")
    print(f"   - Joint predictions CSV (val): joint_predictions_{model_name}_val.csv")
    print(f"   - EMG & joint time series CSV (val): emg_joint_timeseries_{model_name}_val.csv")
    print(f"   - Joint predictions CSV (test): joint_predictions_{model_name}_test.csv")
    print(f"   - EMG & joint time series CSV (test): emg_joint_timeseries_{model_name}_test.csv")
    print(f"   - Training report: training_report_{model_name}.txt and .csv")
    print(f"   - Hyperparameters and data info: HyperparametersDatas_{model_name}.txt")
    print(f"   - Best model: {results.get('best_checkpoint', 'Not saved')}")








# 强制从 metrics.csv 提取每个 epoch 的损失（稳健方法）
    try:
        import pandas as pd
        import os
        log_dir = trainer.logger.log_dir if trainer.logger else None
        if log_dir:
            metrics_csv = os.path.join(log_dir, 'metrics.csv')
            if os.path.exists(metrics_csv):
                df = pd.read_csv(metrics_csv)
                # 提取 train_loss_epoch 和 val_loss_epoch 列（这些列每个 epoch 只有一行）
                epoch_loss = df[['epoch', 'train_loss_epoch', 'val_loss_epoch']].dropna(how='all')
                epoch_loss = epoch_loss.drop_duplicates(subset='epoch', keep='last')
                epoch_loss = epoch_loss.sort_values('epoch')
                # 保存
                epoch_loss.to_csv(save_dir / f'loss_per_epoch_{model_name}.csv', index=False)
                print(f"✅ Loss per epoch saved to {save_dir / f'loss_per_epoch_{model_name}.csv'}")
                
                # 绘图
                import matplotlib.pyplot as plt
                plt.figure(figsize=(10,6))
                if 'train_loss_epoch' in epoch_loss.columns:
                    plt.plot(epoch_loss['epoch'], epoch_loss['train_loss_epoch'], marker='o', label='Train Loss')
                if 'val_loss_epoch' in epoch_loss.columns:
                    plt.plot(epoch_loss['epoch'], epoch_loss['val_loss_epoch'], marker='s', label='Val Loss')
                plt.xlabel('Epoch')
                plt.ylabel('Loss')
                plt.title(f'Training and Validation Loss - {model_name}')
                plt.legend()
                plt.grid(True)
                plt.savefig(save_dir / f'loss_curve_{model_name}.png', dpi=300, bbox_inches='tight')
                plt.close()
                print(f"✅ Loss curve saved to {save_dir / f'loss_curve_{model_name}.png'}")
    except Exception as e:
        print(f"⚠️ Failed to extract loss from metrics.csv: {e}")

# ========== 自动提取每个 epoch 的损失并绘图 ==========
    if config.train and config.eval:
        try:
            import pandas as pd
            import matplotlib.pyplot as plt
            import os
            # 获取 metrics.csv 路径
            if trainer.logger and hasattr(trainer.logger, 'log_dir'):
                metrics_path = os.path.join(trainer.logger.log_dir, 'metrics.csv')
                if os.path.exists(metrics_path):
                    df = pd.read_csv(metrics_path)
                    # 提取 epoch 级别的损失（我们刚记录的 train_loss_epoch 和 val_loss_epoch）
                    epoch_loss = df[['epoch', 'train_loss_epoch', 'val_loss_epoch']].dropna()
                    # 去重，每个 epoch 只保留最后一行（实际上应该只有一行）
                    epoch_loss = epoch_loss.drop_duplicates(subset='epoch', keep='last').sort_values('epoch')
                    # 保存 CSV
                    epoch_loss.to_csv(save_dir / f'loss_per_epoch_{model_name}.csv', index=False)
                    print(f"✅ Saved loss per epoch to {save_dir / f'loss_per_epoch_{model_name}.csv'}")
                    # 绘图
                    if len(epoch_loss) > 0:
                        plt.figure(figsize=(10,6))
                        if 'train_loss_epoch' in epoch_loss.columns:
                            plt.plot(epoch_loss['epoch'], epoch_loss['train_loss_epoch'], marker='o', label='Train Loss')
                        if 'val_loss_epoch' in epoch_loss.columns:
                            plt.plot(epoch_loss['epoch'], epoch_loss['val_loss_epoch'], marker='s', label='Val Loss')
                        plt.xlabel('Epoch')
                        plt.ylabel('Loss')
                        plt.title(f'Loss Curve - {model_name}')
                        plt.legend()
                        plt.grid(True)
                        plt.savefig(save_dir / f'loss_curve_{model_name}.png', dpi=300, bbox_inches='tight')
                        plt.close()
                        print(f"✅ Saved loss curve to {save_dir / f'loss_curve_{model_name}.png'}")
        except Exception as e:
            print(f"⚠️ Failed to extract loss curve: {e}")


    return results

def validate_transformer_config(cfg):
    """验证 Transformer 配置是否合理"""
    pose_cfg = cfg.pose_module
    
    # 检查关键参数
    required_params = ['d_model', 'nhead', 'num_layers', 'dim_feedforward', 'feature_channels']
    for param in required_params:
        if hasattr(pose_cfg, param):
            print(f"✅ {param}: {getattr(pose_cfg, param)}")
        else:
            print(f"❌ 缺少参数: {param}")
    
    # 验证 nhead 是否能整除 d_model
    if pose_cfg.d_model % pose_cfg.nhead != 0:
        print(f"⚠️  警告: d_model ({pose_cfg.d_model}) 不能被 nhead ({pose_cfg.nhead}) 整除")
    return True









def create_spyder_config():
    """创建专门用于Spyder运行的配置"""
    from hydra import compose, initialize_config_dir
    import os
    
    config_dir = str(BASE_DIR / "../config")
    
    with initialize_config_dir(config_dir=config_dir, version_base="1.1"):
        data_location = r"XXX\"
        cfg = compose(config_name="base", overrides=[
            "train=True",
            "eval=True", 
            "experiment=XX",
            "trainer.max_epochs=20",
            "data_split=mini_split",
            f'data_location="{data_location}"',
  
            
            
# =============================================================================
#             "datamodule=default",                  # 使用 default.yaml
#             "datamodule.window_length=400",        # 窗口长度
#             "datamodule.val_test_window_length=400",
#             "datamodule.padding=[0,0]",
#             "datamodule.skip_ik_failures=True",
#             
#             "transforms=rotation_augmentation",
#             
#             
#             
# =============================================================================

            
            #"pose_module=transformer_pose",  # 使用 Transformer模型
            
            

        ])
        return cfg
    
    
    
    
    
    
    

@hydra.main(config_path="../config", config_name="base", version_base="1.1")
def cli(config: DictConfig):
    results = train_enhanced(config)
    return results

def run_spyder():
    """专门为Spyder环境设计的运行函数"""
    print("🔬 EMG2POSE Enhanced Training - Spyder Version")
    print("Optimizations:")
    print("  - CSV export delayed until end of training for better performance")
    print("  - Loss trends visualization added")
    print("  - Both validation and test set export supported")
    print(f"Results will be saved to: {RESULTS_DIR}")
    
    os.chdir(BASE_DIR)
    os.environ['HYDRA_FULL_ERROR'] = '1'
    
    try:
        # 使用专门为Spyder创建的配置
        config = create_spyder_config()
        results = train_enhanced(config)
        return results
    except Exception as e:
        print(f"❌ Training failed with error: {e}")
        import traceback
        traceback.print_exc()


import time  
if __name__ == "__main__":
    t = time.time()  #  记录时间
    run_spyder()
    print(f"本次运行{int((time.time()-t)//60)}分钟{int((time.time()-t)%60)}秒") 