"""
可视化补丁文件 - 修复并行处理和手腕变换问题
修复问题：
1. 手腕变换为None时的处理
2. 颜色参数传递不正确
3. 镜像处理可能影响动作显示
"""

import numpy as np
import torch
from tqdm import tqdm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import sys
import os

# 添加项目根目录到路径，确保可以导入emg2pose模块
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# ==================== 直接复制必要的函数，避免导入问题 ====================

def load_default_hand_model():
    """直接复制原始函数，避免导入问题"""
    import json
    import pathlib
    from emg2pose.UmeTrack.lib.tracker.video_pose_data import load_hand_model_from_dict
    from emg2pose.UmeTrack.lib.common.hand import HandModel
    
    global _HAND_MODEL_CACHE
    if _HAND_MODEL_CACHE is None:
        umetrack_dir = pathlib.Path(__file__).parent / "UmeTrack"
        default_hand_model_path = umetrack_dir / "dataset" / "generic_hand_model.json"
        with open(default_hand_model_path, "rb") as fp:
            hand_model_dict = json.load(fp)
        _HAND_MODEL_CACHE = load_hand_model_from_dict(hand_model_dict)
    return _HAND_MODEL_CACHE

_HAND_MODEL_CACHE = None

def skin_vertices_np_fixed(profile, joint_angles, wrist_transforms=None):
    """修复版本：正确处理wrist_transforms为None的情况"""
    from emg2pose.UmeTrack.lib.common.hand_skinning import _skin_points
    
    with torch.no_grad():
        joint_angles_tensor = torch.from_numpy(joint_angles).float()
        
        # 处理wrist_transforms为None的情况
        if wrist_transforms is None:
            # 创建一个默认的单位矩阵变换
            leading_dims = joint_angles_tensor.shape[:-1]
            device = joint_angles_tensor.device
            dtype = joint_angles_tensor.dtype
            
            # 创建单位矩阵
            affine_identity = torch.eye(4, device=device, dtype=dtype)
            
            # 广播到正确的形状
            if leading_dims:
                wrist_transforms_tensor = affine_identity.unsqueeze(0).repeat(
                    np.prod(leading_dims), 1, 1
                )
            else:
                wrist_transforms_tensor = affine_identity.unsqueeze(0)
        else:
            wrist_transforms_tensor = torch.from_numpy(wrist_transforms).float()
        
        vertices = _skin_points(
            profile.joint_rest_positions,
            profile.joint_rotation_axes,
            profile.dense_bone_weights,
            joint_angles_tensor,
            profile.mesh_vertices,
            wrist_transforms_tensor,
        )
    return vertices.numpy()

# ==================== 修复颜色和镜像问题 ====================

def plot_hand_mesh_matplotlib_fixed(joint_angles, flip=False, figsize=(8, 6), dpi=80, 
                                   color=(0.94, 0.88, 0.82), edge_color=(0.4, 0.4, 0.4, 0.5),
                                   auto_range=True, view_angle=None):
    """
    修复版本的手部网格绘制
    """
    vertices, triangles = skin_mesh_from_angles_fixed(joint_angles, flip=flip)
    
    # 创建图形
    fig = plt.figure(figsize=figsize, dpi=dpi)
    ax = fig.add_subplot(111, projection='3d')
    
    # 创建多边形集合
    poly_collection = Poly3DCollection(
        vertices[triangles.astype(int)],
        facecolors=[color] * len(triangles),
        edgecolors=edge_color,
        linewidths=0.3,
        alpha=1.0
    )
    
    ax.add_collection3d(poly_collection)
    
    # 设置坐标轴范围 - 使用自动范围确保所有动作可见
    x_min, x_max = vertices[:, 0].min(), vertices[:, 0].max()
    y_min, y_max = vertices[:, 1].min(), vertices[:, 1].max()
    z_min, z_max = vertices[:, 2].min(), vertices[:, 2].max()
    
    # 添加适当边距
    margin = max((x_max - x_min), (y_max - y_min), (z_max - z_min)) * 0.1
    margin = max(margin, 10)  # 最小边距
    
    ax.set_xlim([x_min - margin, x_max + margin])
    ax.set_ylim([y_min - margin, y_max + margin])
    ax.set_zlim([z_min - margin, z_max + margin])
    
    # 设置视角
    if view_angle is None:
        # 默认视角，确保左右手都能清晰看到
        ax.view_init(elev=10, azim=-90)
    else:
        ax.view_init(elev=view_angle[0], azim=view_angle[1])
    
    # 隐藏坐标轴
    ax.set_axis_off()
    
    # 紧凑布局
    plt.tight_layout(pad=0)
    
    return fig, ax

def skin_mesh_from_angles_fixed(joint_angles, user_profile=None, flip=False):
    """
    修复版本的皮肤网格生成，确保镜像处理正确
    """
    from emg2pose.UmeTrack.lib.common.hand import HandModel
    
    if user_profile is None:
        user_profile = load_default_hand_model()
    
    # 修复镜像处理
    if flip:
        # 创建镜像版本
        mirrored_joint_rotation_axes = user_profile.joint_rotation_axes.clone()
        mirrored_joint_rest_positions = user_profile.joint_rest_positions.clone()
        mirrored_landmark_rest_positions = user_profile.landmark_rest_positions.clone()
        mirrored_mesh_vertices = user_profile.mesh_vertices.clone()

        # 镜像处理：翻转X轴
        mirrored_joint_rotation_axes[..., 0] *= -1  # 翻转X轴旋转
        mirrored_joint_rest_positions[..., 0] *= -1
        mirrored_landmark_rest_positions[..., 0] *= -1
        mirrored_mesh_vertices[..., 0] *= -1

        # 创建镜像手部模型
        user_profile = HandModel(
            joint_rotation_axes=mirrored_joint_rotation_axes,
            joint_rest_positions=mirrored_joint_rest_positions,
            joint_frame_index=user_profile.joint_frame_index,
            joint_parent=user_profile.joint_parent,
            joint_first_child=user_profile.joint_first_child,
            joint_next_sibling=user_profile.joint_next_sibling,
            landmark_rest_positions=mirrored_landmark_rest_positions,
            landmark_rest_bone_weights=user_profile.landmark_rest_bone_weights,
            landmark_rest_bone_indices=user_profile.landmark_rest_bone_indices,
            hand_scale=user_profile.hand_scale,
            mesh_vertices=mirrored_mesh_vertices,
            mesh_triangles=user_profile.mesh_triangles,
            dense_bone_weights=user_profile.dense_bone_weights,
            joint_limits=user_profile.joint_limits,
        )

    vertices = skin_vertices_np_fixed(user_profile, joint_angles)
    triangles = user_profile.mesh_triangles.numpy()
    return vertices, triangles

# ==================== 修复颜色映射 ====================

def get_color_rgb(color_name):
    """
    将颜色名称转换为RGB值
    """
    color_map = {
        "lightpink": (1.0, 0.71, 0.76),    # 粉红色
        "pink": (1.0, 0.75, 0.8),          # 粉红
        "blue": (0.0, 0.0, 1.0),           # 蓝色
        "red": (1.0, 0.0, 0.0),            # 红色
        "green": (0.0, 1.0, 0.0),          # 绿色
        "gray": (0.5, 0.5, 0.5),           # 灰色
        "lightgray": (0.827, 0.827, 0.827), # 浅灰色
        "darkgray": (0.663, 0.663, 0.663),  # 深灰色
        "white": (1.0, 1.0, 1.0),          # 白色
        "black": (0.0, 0.0, 0.0),          # 黑色
        "yellow": (1.0, 1.0, 0.0),         # 黄色
        "orange": (1.0, 0.647, 0.0),       # 橙色
        "purple": (0.5, 0.0, 0.5),         # 紫色
        "brown": (0.647, 0.165, 0.165),    # 棕色
        "cyan": (0.0, 1.0, 1.0),           # 青色
        "magenta": (1.0, 0.0, 1.0),        # 洋红色
    }
    
    # 如果是RGB元组，直接返回
    if isinstance(color_name, (tuple, list)) and len(color_name) == 3:
        return tuple(color_name)
    
    # 如果是颜色名称，返回对应的RGB
    return color_map.get(color_name, (0.5, 0.5, 0.5))  # 默认灰色

# ==================== 修复的主函数 - 使用串行处理避免导入问题 ====================

def plot_hand_mesh_fixed(joint_angles, color="lightpink", flip=False, 
                        auto_range=True, view_angle=None, **kwargs):
    """
    修复版本的手部网格绘制主函数
    """
    rgb_color = get_color_rgb(color)
    
    fig, ax = plot_hand_mesh_matplotlib_fixed(
        joint_angles, 
        flip=flip, 
        color=rgb_color,
        auto_range=auto_range,
        view_angle=view_angle
    )
    
    return fig

def fig_to_array_fixed(fig, scale=1):
    """修复版本的图形转数组"""
    if scale != 1:
        fig.set_dpi(fig.get_dpi() * scale)
    
    fig.canvas.draw()
    
    buf = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
    buf = buf.reshape(fig.canvas.get_width_height()[::-1] + (3,))
    
    plt.close(fig)
    
    return buf

def _joint_angles_to_frame_fixed(joint_angles, **kwargs):
    """修复版本的单帧处理"""
    fig = plot_hand_mesh_fixed(joint_angles=joint_angles, **kwargs)
    frame_array = fig_to_array_fixed(fig, scale=kwargs.get('scale', 1))
    return frame_array

def joint_angles_to_frames_fixed(joint_angles_t, color="lightpink", flip=False, 
                               auto_range=True, view_angle=None, **kwargs):
    """
    修复版本的串行帧生成 - 避免并行导入问题
    """
    frames = []
    for joint_angles in tqdm(joint_angles_t, desc="生成帧"):
        frame = _joint_angles_to_frame_fixed(
            joint_angles=joint_angles, 
            color=color,
            flip=flip,
            auto_range=auto_range,
            view_angle=view_angle,
            **kwargs
        )
        frames.append(frame)
    
    return np.array(frames)

def joint_angles_to_frames_parallel_fixed(joint_angles, color="lightpink", flip=False,
                                        auto_range=True, view_angle=None, n_jobs=1, **kwargs):
    """
    修复版本的"并行"帧生成 - 实际上使用串行避免导入问题
    为了兼容性保留此函数，但内部使用串行处理
    """
    print(f"🚀 开始生成 {len(joint_angles)} 帧 (使用串行处理避免导入问题)")
    print(f"📊 参数: color={color}, flip={flip}")
    
    # 由于并行处理有导入问题，我们使用串行处理
    return joint_angles_to_frames_fixed(
        joint_angles, 
        color=color, 
        flip=flip,
        auto_range=auto_range,
        view_angle=view_angle,
        **kwargs
    )

# ==================== 对比可视化函数 ====================

def create_comparison_video(gt_joint_angles, pred_joint_angles, 
                          gt_color="gray", pred_color="lightpink",
                          gt_flip=False, pred_flip=False,
                          n_jobs=1, fps=30):
    """
    创建对比视频 - 修复版本，使用串行处理
    """
    print("🎬 开始生成对比视频...")
    
    # 生成GT帧
    print("📹 生成真实值帧 (GT)...")
    gt_frames = joint_angles_to_frames_parallel_fixed(
        gt_joint_angles, 
        color=gt_color, 
        flip=gt_flip,
        n_jobs=n_jobs
    )
    
    # 生成预测帧
    print("📹 生成预测值帧 (Pred)...")
    pred_frames = joint_angles_to_frames_parallel_fixed(
        pred_joint_angles, 
        color=pred_color, 
        flip=pred_flip,
        n_jobs=n_jobs
    )
    
    # 移除可能的alpha通道
    if gt_frames.shape[-1] == 4:
        gt_frames = gt_frames[..., :3]
    if pred_frames.shape[-1] == 4:
        pred_frames = pred_frames[..., :3]
    
    print(f"✅ 帧生成完成: GT={len(gt_frames)}帧, Pred={len(pred_frames)}帧")
    
    return gt_frames, pred_frames

def preview_comparison(gt_joint_angles, pred_joint_angles, 
                      gt_color="gray", pred_color="lightpink",
                      gt_flip=False, pred_flip=False):
    """
    预览对比的第一帧
    """
    print("👀 预览第一帧对比...")
    
    # GT预览
    fig_gt, ax_gt = plot_hand_mesh_matplotlib_fixed(
        gt_joint_angles[0], 
        color=get_color_rgb(gt_color),
        flip=gt_flip
    )
    ax_gt.set_title("GT - 第一帧")
    plt.show()
    plt.close(fig_gt)
    
    # Pred预览
    fig_pred, ax_pred = plot_hand_mesh_matplotlib_fixed(
        pred_joint_angles[0], 
        color=get_color_rgb(pred_color),
        flip=pred_flip
    )
    ax_pred.set_title("Pred - 第一帧")
    plt.show()
    plt.close(fig_pred)

def remove_alpha_channel_fixed(frames):
    """修复版本的移除alpha通道"""
    if frames.shape[-1] == 4:
        return frames[..., :3]
    return frames

# ==================== 快速测试函数 ====================

def quick_test():
    """快速测试函数"""
    print("✅ 可视化补丁文件加载成功！")
    print("📋 可用函数:")
    print("  - joint_angles_to_frames_parallel_fixed()")
    print("  - create_comparison_video()")
    print("  - preview_comparison()")
    print("⚠️  注意: 由于并行导入问题，当前使用串行处理")

if __name__ == "__main__":
    quick_test()