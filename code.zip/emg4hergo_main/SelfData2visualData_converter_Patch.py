# data_converter.py

import pandas as pd
import numpy as np
import torch
from pathlib import Path

def convert_csv_to_time_series(csv_file_path, model_name=None):
    """
    将CSV预测数据转换为时间序列格式，兼容参考代码的preds_np和joint_angles_np
    
    Args:
        csv_file_path: CSV文件路径
        model_name: 指定模型名称，如果为None则使用文件中的第一个模型
    
    Returns:
        preds_np: 预测值数组 (时间步数, 20)
        joint_angles_np: 真实值数组 (时间步数, 20)
        sample_info: 样本信息字典
    """
    
    print(f"📁 正在读取数据文件: {csv_file_path}")
    
    # 读取CSV文件
    try:
        df = pd.read_csv(csv_file_path)
    except Exception as e:
        print(f"❌ 读取CSV文件失败: {e}")
        return None, None, None
    
    print(f"✅ 成功读取数据，总行数: {len(df)}")
    
    # 如果未指定模型名称，使用文件中的第一个模型
    if model_name is None:
        model_name = df['model_name'].iloc[0]
        print(f"🔍 自动检测到模型: {model_name}")
    
    # 筛选指定模型的数据
    model_df = df[df['model_name'] == model_name]
    
    if len(model_df) == 0:
        print(f"❌ 在文件中找不到模型 '{model_name}'")
        available_models = df['model_name'].unique()
        print(f"📊 可用的模型: {list(available_models)}")
        return None, None, None
    
    print(f"📊 模型 '{model_name}' 的数据行数: {len(model_df)}")
    
    # 获取唯一的样本索引并排序
    sample_indices = sorted(model_df['sample_index'].unique())
    num_samples = len(sample_indices)
    num_joints = model_df['joint_index'].nunique()
    
    print(f"📈 样本数量: {num_samples}")
    print(f"🔗 关节数量: {num_joints}")
    
    # 初始化数组
    preds_array = np.zeros((num_samples, num_joints))
    true_array = np.zeros((num_samples, num_joints))
    hand_sides = []
    
    # 按样本索引填充数据
    for i, sample_idx in enumerate(sample_indices):
        sample_data = model_df[model_df['sample_index'] == sample_idx]
        
        # 确保样本数据按关节索引排序
        sample_data = sample_data.sort_values('joint_index')
        
        # 填充预测值和真实值
        preds_array[i, :] = sample_data['predicted_value'].values
        true_array[i, :] = sample_data['true_value'].values
        
        # 记录手部侧别（使用第一个关节的手部侧别）
        hand_side = sample_data['hand_side'].iloc[0]
        hand_sides.append(hand_side)
    
    # 收集样本信息
    sample_info = {
        'model_name': model_name,
        'num_samples': num_samples,
        'num_joints': num_joints,
        'sample_indices': sample_indices,
        'hand_sides': hand_sides,
        'total_time_steps': num_samples,
        'file_path': csv_file_path
    }
    
    print(f"✅ 数据转换完成!")
    print(f"📏 预测值形状: {preds_array.shape}")
    print(f"📏 真实值形状: {true_array.shape}")
    print(f"👐 左手样本: {hand_sides.count('left')}, 右手样本: {hand_sides.count('right')}")
    
    return preds_array, true_array, sample_info

def prepare_data_for_visualization(csv_directory, model_name=None, target_model=None):
    """
    准备可视化数据，自动检测目录中的CSV文件
    
    Args:
        csv_directory: CSV文件目录
        model_name: 指定模型名称
        target_model: 目标模型名称（如果为None，则使用model_name）
    
    Returns:
        preds_np: 预测值数组
        joint_angles_np: 真实值数组  
        sample_info: 样本信息
    """
    
    csv_dir = Path(csv_directory)
    
    if not csv_dir.exists():
        print(f"❌ 目录不存在: {csv_directory}")
        return None, None, None
    
    # 查找CSV文件
    csv_files = list(csv_dir.glob("hand_pose_predictions_*_all_samples.csv"))


    if not csv_files:
        print(f"❌ 在目录中未找到CSV文件: {csv_directory}")
        return None, None, None
    
    print(f"📁 找到 {len(csv_files)} 个CSV文件")
    
    # 如果指定了模型名称，查找对应的文件
    if model_name:
        target_files = [f for f in csv_files if model_name in f.name]
        if not target_files:
            print(f"❌ 未找到模型 '{model_name}' 的CSV文件")
            print(f"📊 可用的文件: {[f.name for f in csv_files]}")
            return None, None, None
        csv_file = target_files[0]
    else:
        # 使用第一个文件
        csv_file = csv_files[0]
        print(f"🔍 使用第一个文件: {csv_file.name}")
    
    # 转换数据
    preds_np, joint_angles_np, sample_info = convert_csv_to_time_series(
        csv_file, target_model or model_name
    )
    
    return preds_np, joint_angles_np, sample_info

def create_dummy_batch_data(preds_np, joint_angles_np, device='cpu'):
    """
    创建与参考代码兼容的虚拟批次数据
    
    Args:
        preds_np: 预测值数组 (时间步数, 关节数)
        joint_angles_np: 真实值数组 (时间步数, 关节数)
        device: 设备
    
    Returns:
        batch: 批次数据字典
    """
    
    # 转置数据以匹配参考代码的形状 (特征, 时间步)
    preds_tensor = torch.from_numpy(preds_np.T).float().unsqueeze(0).to(device)
    joint_angles_tensor = torch.from_numpy(joint_angles_np.T).float().unsqueeze(0).to(device)
    
    # 创建虚拟的IK失败标记（全为1，表示没有失败）
    no_ik_failure_tensor = torch.ones((1, preds_np.shape[0])).float().to(device)
    
    batch = {
        "emg": torch.zeros((1, 16, preds_np.shape[0])).float().to(device),  # 虚拟EMG数据
        "joint_angles": joint_angles_tensor,
        "no_ik_failure": no_ik_failure_tensor,
    }
    
    print(f"✅ 虚拟批次数据创建完成!")
    print(f"📊 EMG形状: {batch['emg'].shape}")
    print(f"📊 关节角度形状: {batch['joint_angles'].shape}")
    print(f"📊 IK失败标记形状: {batch['no_ik_failure'].shape}")
    
    return batch

# 使用示例
def main():
    """主函数示例"""
    
    # 你的CSV文件目录
    csv_directory = r"D:\ComputeData\Ergonomics_numeric\results\emg2pose_regression\training_20251125_105708\csv_exports_all"


    # 选择模型（可选）
    model_name = "Transformer"  # 可以是 "Transformer", "BayesianNet", "CNN", 等
    
    print("🚀 开始数据转换流程...")
    
    # 准备数据
    preds_np, joint_angles_np, sample_info = prepare_data_for_visualization(
        csv_directory, model_name=model_name
    )
    
    if preds_np is None:
        print("❌ 数据准备失败!")
        return
    
    print("\n" + "="*50)
    print("📊 数据统计:")
    print(f"   模型名称: {sample_info['model_name']}")
    print(f"   样本数量: {sample_info['num_samples']}")
    print(f"   关节数量: {sample_info['num_joints']}")
    print(f"   总时间步: {sample_info['total_time_steps']}")
    print(f"   文件路径: {sample_info['file_path']}")
    print("="*50)
    
    # 创建虚拟批次数据（用于兼容参考代码）
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    batch = create_dummy_batch_data(preds_np, joint_angles_np, device)
    
    print("\n✅ 数据转换完成，现在可以使用参考代码进行可视化!")
    
    # 返回转换后的数据，便于在外部使用
    return {
        'preds_np': preds_np,
        'joint_angles_np': joint_angles_np, 
        'batch': batch,
        'sample_info': sample_info
    }

# 直接运行测试
if __name__ == "__main__":
    result = main()
    
    if result:
        print(f"\n🎉 转换成功！")
        print(f"📏 preds_np形状: {result['preds_np'].shape}")
        print(f"📏 joint_angles_np形状: {result['joint_angles_np'].shape}")
        
        # 这里可以添加调用参考可视化代码的逻辑
        # 例如：
        # from reference_visualization_code import create_3d_animation
        # create_3d_animation(result['preds_np'], result['joint_angles_np'])