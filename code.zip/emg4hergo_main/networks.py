# Copyright (c) [您的姓名/机构]
# All rights reserved.
   
    
    
class Chomp1d(nn.Module):

    def __init__(self, chomp_size):
        super(Chomp1d, self).__init__()
        self.chomp_size = chomp_size

    def forward(self, x):
        return x[:, :, :-self.chomp_size] if self.chomp_size > 0 else x


class TemporalBlock(nn.Module):

    def __init__(self, in_channels, out_channels, kernel_size, stride, dilation, dropout=0.2):
        super(TemporalBlock, self).__init__()
        padding = (kernel_size - 1) * dilation
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size,
                               stride=stride, padding=padding, dilation=dilation)
        self.chomp1 = Chomp1d(padding)
        self.relu1 = nn.ReLU()
        self.dropout1 = nn.Dropout(dropout)

        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size,
                               stride=1, padding=padding, dilation=dilation)
        self.chomp2 = Chomp1d(padding)
        self.relu2 = nn.ReLU()
        self.dropout2 = nn.Dropout(dropout)

        self.net = nn.Sequential(
            self.conv1, self.chomp1, self.relu1, self.dropout1,
            self.conv2, self.chomp2, self.relu2, self.dropout2
        )
        self.downsample = nn.Conv1d(in_channels, out_channels, 1, stride=stride) if in_channels != out_channels or stride != 1 else None
        self.relu = nn.ReLU()
        self.stride = stride

    def forward(self, x):
        out = self.net(x)
        res = x if self.downsample is None else self.downsample(x)

        if out.shape[-1] != res.shape[-1]:

            min_len = min(out.shape[-1], res.shape[-1])
            out = out[:, :, :min_len]
            res = res[:, :, :min_len]
        return self.relu(out + res)


class TcnNetwork(nn.Module):
    def __init__(self, in_channels, channel_sizes, kernel_sizes, strides, dilations, dropout=0.2):
        super(TcnNetwork, self).__init__()
        assert len(channel_sizes) == len(kernel_sizes) == len(strides) == len(dilations)
        layers = []
        self.left_context = 0
        current_stride_product = 1
        for i, (out_ch, k, s, d) in enumerate(zip(channel_sizes, kernel_sizes, strides, dilations)):
            layers.append(TemporalBlock(in_channels, out_ch, k, s, d, dropout))
            self.left_context += (k - 1) * d * current_stride_product
            current_stride_product *= s
            in_channels = out_ch
        self.network = nn.Sequential(*layers)
        self.right_context = 0  # TCN 是 causal 的，没有右上下文
    def forward(self, x):
        return self.network(x)