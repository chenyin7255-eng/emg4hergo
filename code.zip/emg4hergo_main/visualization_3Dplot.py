import numpy as np
import plotly.graph_objects as go
from tqdm import tqdm
import torch

def safe_skin_mesh_from_angles(joint_angles, user_profile=None, flip=False):
    """安全的手部网格生成函数，处理设备类型转换"""
    from emg2pose.visualization import load_default_hand_model, skin_vertices_np, HandModel
    
    if user_profile is None:
        user_profile = load_default_hand_model()
    
    # 确保输入是 numpy 数组
    if hasattr(joint_angles, 'cpu'):
        joint_angles_np = joint_angles.cpu().numpy()
    else:
        joint_angles_np = joint_angles
    
    # 确保是 float 类型
    joint_angles_np = joint_angles_np.astype(np.float32)
    
    if flip:
        mirrored_joint_rotation_axes = user_profile.joint_rotation_axes.clone()
        mirrored_joint_rest_positions = user_profile.joint_rest_positions.clone()
        mirrored_landmark_rest_positions = user_profile.landmark_rest_positions.clone()
        mirrored_mesh_vertices = user_profile.mesh_vertices.clone()

        mirrored_joint_rotation_axes[..., 1:] *= -1
        mirrored_joint_rest_positions[..., 0] *= -1
        mirrored_landmark_rest_positions[..., 0] *= -1
        mirrored_mesh_vertices[..., 0] *= -1

        user_profile = HandModel(
            joint_rotation_axes=mirrored_joint_rotation_axes,
            joint_rest_positions=mirrored_joint_rest_positions,
            joint_frame_index=user_profile.joint_frame_index,
            joint_parent=user_profile.joint_parent,
            joint_first_child=user_profile.joint_first_child,
            joint_next_sibling=user_profile.joint_next_sibling,
            landmark_rest_positions=mirrored_landmark_rest_positions,
            landmark_rest_bone_weights=user_profile.landmark_rest_bone_weights,
            landmark_rest_bone_indices=user_profile.landmark_rest_bone_indices,
            hand_scale=user_profile.hand_scale,
            mesh_vertices=mirrored_mesh_vertices,
            mesh_triangles=user_profile.mesh_triangles,
            dense_bone_weights=user_profile.dense_bone_weights,
            joint_limits=user_profile.joint_limits,
        )

    vertices = skin_vertices_np(user_profile, joint_angles_np)
    triangles = user_profile.mesh_triangles.numpy()
    return vertices, triangles

def get_enhanced_lighting():
    """增强的光照设置，确保网格可见"""
    return dict(
        ambient=0.8,
        diffuse=0.9, 
        specular=0.3,
        roughness=0.5,
        fresnel=0.1
    ), dict(x=100, y=200, z=0)

def generate_robust_hand_mesh_from_joint_angles(
    joint_angles, color="lightblue", flip=False, opacity=0.9, **mesh_kwargs
):
    """更健壮的手部网格生成函数"""
    try:
        # 确保输入格式正确
        if hasattr(joint_angles, 'cpu'):
            joint_angles_np = joint_angles.cpu().numpy()
        else:
            joint_angles_np = joint_angles
        
        # 如果是单帧数据，确保形状正确
        if joint_angles_np.ndim == 1:
            joint_angles_np = joint_angles_np.reshape(1, -1)
        
        lighting, lightposition = get_enhanced_lighting()
        
        vertices, triangles = safe_skin_mesh_from_angles(joint_angles_np[0], flip=flip)
        
        # 检查网格数据是否有效
        if np.any(np.isnan(vertices)) or np.any(np.isinf(vertices)):
            print("警告: 检测到无效的顶点数据")
            vertices = np.nan_to_num(vertices)
        
        x, y, z = vertices.T
        i, j, k = triangles.T
        
        # 创建网格，确保设置正确的参数
        mesh = go.Mesh3d(
            x=x,
            y=y, 
            z=z,
            i=i,
            j=j,
            k=k,
            color=color,
            opacity=opacity,
            lighting=lighting,
            lightposition=lightposition,
            flatshading=True,
            showscale=False,
            **mesh_kwargs,
        )
        return mesh
        
    except Exception as e:
        print(f"生成手部网格时出错: {e}")
        # 返回一个简单的立方体作为备用
        return go.Mesh3d(
            x=[0, 1, 1, 0, 0, 1, 1, 0],
            y=[0, 0, 1, 1, 0, 0, 1, 1],
            z=[0, 0, 0, 0, 1, 1, 1, 1],
            i=[0, 0, 0, 1, 2, 3, 4, 5],
            j=[1, 2, 4, 3, 6, 7, 5, 6],
            k=[2, 4, 1, 6, 7, 5, 6, 7],
            color='red',
            opacity=0.5
        )

def frame_args(duration):
    """动画帧参数"""
    return {
        "frame": {"duration": duration},
        "mode": "immediate",
        "fromcurrent": True,
        "transition": {"duration": duration, "easing": "linear"},
    }

def animate_frames_fixed(initial_data, frames):
    """修复版的动画帧生成"""
    fig = go.Figure(
        data=initial_data,
        frames=frames,
        layout=go.Layout(
            updatemenus=[
                {
                    "buttons": [
                        {
                            "args": [None, frame_args(50)],
                            "label": "播放",
                            "method": "animate",
                        },
                        {
                            "args": [[None], frame_args(0)],
                            "label": "暂停",
                            "method": "animate",
                        },
                    ],
                    "direction": "left",
                    "pad": {"r": 10, "t": 70},
                    "type": "buttons",
                    "x": 0.1,
                    "y": 0,
                }
            ],
        ),
    )

    sliders = [
        {
            "pad": {"b": 10, "t": 60},
            "len": 0.9,
            "x": 0.1,
            "y": 0,
            "steps": [
                {
                    "args": [[f.name], frame_args(0)],
                    "label": str(k),
                    "method": "animate",
                }
                for k, f in enumerate(fig.frames)
            ],
        }
    ]
    fig.update_layout(sliders=sliders)
    return fig

def _set_3d_plot_layout_fixed(
    fig: go.Figure, auto_range=True, flip=False, clean_background=True
):
    """修复版的3D绘图布局设置"""
    DEFAULT_RANGES = {"x": [-20, 200], "y": [-100, 40], "z": [-70, 100]}
    
    xmin, xmax = DEFAULT_RANGES["x"]
    ymin, ymax = DEFAULT_RANGES["y"]
    zmin, zmax = DEFAULT_RANGES["z"]

    if flip:
        xmin *= -1
        xmax *= -1
        xmin, xmax = xmax, xmin

    if auto_range:
        # 自动计算范围
        x_coords = []
        y_coords = []
        z_coords = []
        
        for trace in fig.data:
            if hasattr(trace, 'x') and trace.x is not None:
                x_coords.extend(trace.x)
            if hasattr(trace, 'y') and trace.y is not None:
                y_coords.extend(trace.y)
            if hasattr(trace, 'z') and trace.z is not None:
                z_coords.extend(trace.z)
        
        if x_coords:
            xmin, xmax = min(x_coords), max(x_coords)
            ymin, ymax = min(y_coords), max(y_coords)
            zmin, zmax = min(z_coords), max(z_coords)
            
            # 添加边距
            x_margin = (xmax - xmin) * 0.1
            y_margin = (ymax - ymin) * 0.1
            z_margin = (zmax - zmin) * 0.1
            
            xmin -= x_margin
            xmax += x_margin
            ymin -= y_margin
            ymax += y_margin
            zmin -= z_margin
            zmax += z_margin

    camera = {
        "eye": {"x": -0.25, "y": -0.9, "z": 0.3},
        "projection": {"type": "perspective"},
    }

    addl_kwargs = dict()
    if clean_background:
        addl_kwargs = dict(
            showbackground=False,
            showline=False,
            zeroline=False,
            showticklabels=False,
            showgrid=False,
            title="",
        )

    xrange = xmax - xmin
    yrange = ymax - ymin
    zrange = zmax - zmin

    xratio = xrange / xrange if xrange > 0 else 1
    yratio = yrange / xrange if xrange > 0 else 1
    zratio = zrange / xrange if xrange > 0 else 1

    w, h = 800, 600
    fig.update_layout(height=h, width=w)
    fig.update_layout(
        scene=dict(
            xaxis=dict(
                range=(xmin, xmax),
                **addl_kwargs,
            ),
            yaxis=dict(
                range=(ymin, ymax),
                **addl_kwargs,
            ),
            zaxis=dict(
                range=(zmin, zmax),
                **addl_kwargs,
            ),
            aspectmode="manual",
            aspectratio=dict(x=xratio, y=yratio, z=zratio),
            camera=camera,
        )
    )
    return fig

def generate_hand_mesh_frames_from_joint_angles_fixed(
    joint_angles, color="lightblue", flip=False, opacity=0.9, **mesh_kwargs
):
    """修复版的手部网格帧生成"""
    frames = []
    initial_data = None
    
    print(f"🎬 开始生成 {len(joint_angles)} 帧动画...")
    
    for ind, ja in tqdm(enumerate(joint_angles), desc="渲染帧"):
        try:
            hand_mesh = generate_robust_hand_mesh_from_joint_angles(
                joint_angles=ja,
                color=color,
                flip=flip,
                opacity=opacity,
                **mesh_kwargs,
            )

            if initial_data is None:
                initial_data = [hand_mesh]

            frame = go.Frame(data=[hand_mesh], name=f"frame{ind}")
            frames.append(frame)
            
        except Exception as e:
            print(f"⚠️ 渲染第 {ind} 帧时出错: {e}")
            continue

    if not initial_data:
        print("❌ 错误: 未能生成任何帧数据")
        # 创建一个空的初始数据
        initial_data = [go.Mesh3d(x=[0], y=[0], z=[0], i=[0], j=[0], k=[0])]
    
    print("✅ 帧生成完成")
    return initial_data, frames

def get_plotly_animation_for_joint_angles_fixed(
    joint_angles,
    flip=False,
    title="",
    color="lightblue",
    opacity=0.9,
    auto_range=True,  # 默认启用自动范围
    clean_background=True,
):
    """修复版的 Plotly 动画函数 - 直接替换原函数"""
    # 确保数据格式正确
    if hasattr(joint_angles, 'cpu'):
        joint_angles_np = joint_angles.cpu().numpy()
    else:
        joint_angles_np = joint_angles
    
    # 确保是 float 类型
    joint_angles_np = joint_angles_np.astype(np.float32)
    
    print(f"📊 处理 {len(joint_angles_np)} 帧数据")
    print(f"🎨 颜色: {color}, 透明度: {opacity}")
    
    # 生成初始数据和帧
    initial_data, frames = generate_hand_mesh_frames_from_joint_angles_fixed(
        joint_angles_np, 
        flip=flip, 
        opacity=opacity, 
        color=color
    )
    
    # 创建动画
    fig = animate_frames_fixed(initial_data, frames)
    
    # 设置布局
    fig = _set_3d_plot_layout_fixed(
        fig, 
        auto_range=auto_range, 
        flip=flip, 
        clean_background=clean_background
    )
    
    # 添加标题
    if title:
        fig.update_layout(title=title)
    
    print("🎉 动画生成完成！")
    return fig












###############用于绘制砖红色上的网格的3D图-交互式的切换视角

import numpy as np
import plotly.graph_objects as go
from tqdm import tqdm
import torch

def generate_patch_style_mesh_and_edges(ja, color="rgb(240, 225, 210)", flip=False, opacity=1.0):
    """
    生成单帧数据：包含哑光 Mesh 和 结构化网格线
    """
    from emg2pose.visualization import skin_mesh_from_angles  # 确保引用原始计算函数
    
    vertices, triangles = skin_mesh_from_angles(ja, flip=flip)
    
    # 确保 triangles 是 numpy int 类型
    if torch.is_tensor(triangles):
        triangles = triangles.detach().cpu().numpy()
    triangles = triangles.astype(np.int32)

    # 1. 仿 Matplotlib 哑光材质的 Mesh3d
    mesh = go.Mesh3d(
        x=vertices[:, 0], y=vertices[:, 1], z=vertices[:, 2],
        i=triangles[:, 0], j=triangles[:, 1], k=triangles[:, 2],
        color=color,
        opacity=opacity,
        # 核心设置：消除油亮感，增加环境光
        lighting=dict(
            ambient=0.8, diffuse=0.5, specular=0.0, roughness=1.0, fresnel=0.0
        ),
        lightposition=dict(x=100, y=200, z=1000),
        flatshading=False,
        name="Hand"
    )

    # 2. 仿 Matplotlib 的结构网格线 (Scatter3d)
    tri_points = vertices[triangles]
    Xe, Ye, Ze = [], [], []
    for T in tri_points:
        # A->B->C->A->None 形成闭合三角形
        Xe.extend([T[0][0], T[1][0], T[2][0], T[0][0], None])
        Ye.extend([T[0][1], T[1][1], T[2][1], T[0][1], None])
        Ze.extend([T[0][2], T[1][2], T[2][2], T[0][2], None])


    edges = go.Scatter3d(
        x=Xe, y=Ye, z=Ze,
        mode="lines",
        line=dict(
            color="rgba(80, 80, 80, 0.98)", # 接近深黑，保留一点点透明度使其不至于太死板
            width=2.0                    # 稍微加粗
        ),
        showlegend=False,
        hoverinfo='skip'                  # 必须加上这个，否则鼠标悬停时会弹出无数坐标框
    )
    
    return [mesh, edges]

def get_plotly_animation_for_joint_angles_patch_v2(
    joint_angles,
    flip=False,
    title="",
    color="rgb(240, 225, 210)", # 使用你喜欢的肉色风格
    opacity=1.0,
    auto_range=False,
    clean_background=True,
):
    """
    保留原有 Plotly 逻辑，但注入 Patch 风格的渲染
    """
    from emg2pose.visualization import animate_frames, _set_3d_plot_layout
    
    frames = []
    initial_data = None

    # 逐帧生成数据 (每帧包含两个 Trace: Mesh + Edges)
    for ind, ja in tqdm(enumerate(joint_angles), desc="Generating 3D Interactive Frames", total=len(joint_angles)):
        traces = generate_patch_style_mesh_and_edges(ja, color=color, flip=flip, opacity=opacity)
        
        if initial_data is None:
            initial_data = traces
            
        frames.append(go.Frame(data=traces, name=f"frame{ind}"))

    # 组装播放器
    fig = animate_frames(initial_data, frames)
    
    # 设置布局
    fig = _set_3d_plot_layout(
        fig, auto_range=auto_range, flip=flip, clean_background=clean_background
    )
    
    # 强制设置背景为纯白，更像 Matplotlib 风格
    if clean_background:
        fig.update_layout(scene_bgcolor="white")

    return fig