import os
import numpy as np
import matplotlib.pyplot as plt
from tqdm.auto import tqdm
from PIL import Image
from emg2pose.utils import downsample
import emg2pose.visualization_Video_Patch as visualization_Video

class Visualization3DHandEMGJointsExporter:
    def __init__(self, col_width=3.35, fontsize=14):
        """
        col_width: 信号图的基准宽度 (inch)
        fontsize: 全局统一字号
        """
        self.col_width = col_width
        self.fs = fontsize
        self._init_style()

    def _init_style(self):
        plt.rcParams['font.family'] = 'serif'
        plt.rcParams['font.serif'] = ['Times New Roman']
        plt.rcParams['axes.unicode_minus'] = False
        # 强制设置所有基础字号，确保绝对统一
        plt.rcParams['font.size'] = self.fs
        plt.rcParams['axes.titlesize'] = self.fs
        plt.rcParams['axes.labelsize'] = self.fs
        plt.rcParams['xtick.labelsize'] = self.fs
        plt.rcParams['ytick.labelsize'] = self.fs

    def process_data(self, data, num_frames, src_fs=2000, target_fs=30):
        raw_joints = data.timeseries["joint_angles"][:]
        raw_emg = data.timeseries["emg"][:]
        joints_30hz = downsample(raw_joints, src_fs, target_fs)
        emg_30hz = downsample(raw_emg, src_fs, target_fs)
        actual_frames = min(num_frames, len(joints_30hz))
        
        print(f"🎬 渲染 3D 手部序列...")
        hand_images = visualization_Video.joint_angles_to_frames(
            joints_30hz[:actual_frames], auto_range=False, scale=0.8, color="lightpink"
        )
        hand_images = visualization_Video.remove_alpha_channel(hand_images)
        return hand_images, joints_30hz[:actual_frames], emg_30hz[:actual_frames]

    def _save_frame(self, i, hand_img, joints, emg, x_max, dir_hand, dir_sig):
        # --- 1. 手部组件：大尺寸，高质量导出 ---
        h_path = os.path.join(dir_hand, f"frame_{i:04d}_hand")
        # 设为 8x8 英寸的大图，方便后期缩放
        fig_h, ax_h = plt.subplots(figsize=(8, 8))
        ax_h.imshow(hand_img); ax_h.axis('off')
        fig_h.savefig(h_path + ".png", dpi=300, bbox_inches='tight', pad_inches=0)
        fig_h.savefig(h_path + ".svg", format='svg', bbox_inches='tight', pad_inches=0)
        plt.close(fig_h)

        # --- 2. 信号组件：紧凑型，字体强制统一 ---
        s_path = os.path.join(dir_sig, f"signal_{i:04d}")
        # 减小高度比例 (原来是 2.8, 现在改为 2.2，更矮更紧凑)
        fig_s = plt.figure(figsize=(self.col_width, self.col_width * 2.2))
        
        # 减小 hspace 使波形贴合更紧密
        gs = fig_s.add_gridspec(2, 1, height_ratios=[1, 3], hspace=0.1)

        # A. 关节角
        ax_j = fig_s.add_subplot(gs[0])
        ax_j.plot(joints, color='dimgray', alpha=0.15, linewidth=0.5)
        ax_j.plot(joints[:i+1], linewidth=0.8)
        ax_j.axvline(x=i, color='red', linewidth=1.0)
        ax_j.set_xlim(0, x_max)
        ax_j.set_title(f"Joint Angles (F{i})", fontsize=self.fs, pad=10)
        ax_j.set_ylabel("Rad", fontsize=self.fs)

        # B. 16通道 EMG
        gs_emg = gs[1].subgridspec(16, 1, hspace=0) # 彻底取消波形间的垂直间距
        colors = plt.cm.viridis(np.linspace(0, 1, 16))
        for ch in range(16):
            ax_e = fig_s.add_subplot(gs_emg[ch])
            ax_e.plot(emg[:, ch], color='dimgray', alpha=0.15, linewidth=0.3)
            ax_e.plot(emg[:i+1, ch], color=colors[ch], linewidth=0.6)
            ax_e.axvline(x=i, color='red', linewidth=0.8)
            ax_e.set_xlim(0, x_max)
            ax_e.set_xticks([]); ax_e.set_yticks([])
            
            # 通道标签强制 14 号字，向左微调避免重叠
            ax_e.set_ylabel(f"C{ch+1}", rotation=0, labelpad=18, va='center', fontsize=self.fs)
            
            if ch == 15:
                # 只显示起始和终点刻度，保持整洁
                ax_e.set_xticks([0, x_max])
                ax_e.set_xlabel("Frames", fontsize=self.fs, labelpad=5)

        fig_s.savefig(s_path + ".svg", format='svg', bbox_inches='tight')
        fig_s.savefig(s_path + ".png", dpi=300, bbox_inches='tight')
        plt.close(fig_s)

    def export(self, data, num_frames=250, output_dir="Pose_EMG_Export"):
        hands, joints, emgs = self.process_data(data, num_frames)
        d_h = os.path.join(output_dir, "hand_pose")
        d_s = os.path.join(output_dir, "signal_plots")
        for d in [d_h, d_s]: os.makedirs(d, exist_ok=True)

        print(f"💾 正在并行导出... (当前统一字号: {self.fs}pt)")
        x_max = len(hands) - 1
        for i in tqdm(range(len(hands))):
            self._save_frame(i, hands[i], joints, emgs, x_max, d_h, d_s)
        print(f"\n✨ 任务完成！手部图已放大，信号图已压缩高度并统一字号。")