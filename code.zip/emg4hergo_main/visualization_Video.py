# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.

import io
import json
import pathlib
from joblib import delayed
import numpy as np
import torch
from tqdm import tqdm
from PIL import Image
import matplotlib
matplotlib.use('Agg')  # 无头模式，提升性能
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

from emg2pose.UmeTrack.lib.tracker.video_pose_data import load_hand_model_from_dict
from emg2pose.UmeTrack.lib.common.hand import HandModel
from emg2pose.UmeTrack.lib.common.hand_skinning import _skin_points
from emg2pose.utils import ProgressParallel

# 全局缓存手部模型
_HAND_MODEL_CACHE = None

def load_hand_model_from_json(filepath: str) -> HandModel:
    with open(filepath, "rb") as fp:
        hand_model_dict = json.load(fp)
    hand_model = load_hand_model_from_dict(hand_model_dict)
    return hand_model

def load_default_hand_model():
    global _HAND_MODEL_CACHE
    if _HAND_MODEL_CACHE is None:
        umetrack_dir = pathlib.Path(__file__).parent / "UmeTrack"
        default_hand_model_path = umetrack_dir / "dataset" / "generic_hand_model.json"
        _HAND_MODEL_CACHE = load_hand_model_from_json(default_hand_model_path)
    return _HAND_MODEL_CACHE

def skin_vertices(
    profile: HandModel,
    joint_angles: torch.Tensor,
    wrist_transforms: torch.Tensor | None = None,
) -> torch.Tensor:

    assert profile.mesh_vertices is not None, "mesh vertices should not be none"
    assert (
        profile.dense_bone_weights is not None
    ), "dense bone weights should not be none"

    if wrist_transforms is None:
        leading_dims = joint_angles.shape[:-1]
        affine_identity = torch.eye(4, device=joint_angles.device, dtype=joint_angles.dtype)
        wrist_transforms = torch.broadcast_to(
            affine_identity, leading_dims + affine_identity.shape
        )

    vertices = _skin_points(
        profile.joint_rest_positions,
        profile.joint_rotation_axes,
        profile.dense_bone_weights,
        joint_angles,
        profile.mesh_vertices,
        wrist_transforms,
    )

    leading_dims = joint_angles.shape[:-1]
    vertices = vertices.reshape(list(leading_dims) + list(vertices.shape[-2:]))
    return vertices

def skin_vertices_np(
    profile: HandModel,
    joint_angles: np.ndarray,
    wrist_transforms: np.ndarray | None = None,
) -> np.ndarray:
    # 优化：使用torch.no_grad()减少内存使用
    with torch.no_grad():
        vertices = skin_vertices(
            profile,
            torch.from_numpy(joint_angles).float(),
            (
                None
                if wrist_transforms is None
                else torch.from_numpy(wrist_transforms).float()
            ),
        )
    return vertices.numpy()

def skin_mesh_from_angles(
    joint_angles,
    user_profile=None,
    flip=False,
):
    if user_profile is None:
        user_profile = load_default_hand_model()
    
    # 简单的镜像处理
    if flip:
        mirrored_joint_rotation_axes = user_profile.joint_rotation_axes.clone()
        mirrored_joint_rest_positions = user_profile.joint_rest_positions.clone()
        mirrored_landmark_rest_positions = user_profile.landmark_rest_positions.clone()
        mirrored_mesh_vertices = user_profile.mesh_vertices.clone()

        mirrored_joint_rotation_axes[..., 1:] *= -1
        mirrored_joint_rest_positions[..., 0] *= -1
        mirrored_landmark_rest_positions[..., 0] *= -1
        mirrored_mesh_vertices[..., 0] *= -1

        user_profile = HandModel(
            joint_rotation_axes=mirrored_joint_rotation_axes,
            joint_rest_positions=mirrored_joint_rest_positions,
            joint_frame_index=user_profile.joint_frame_index,
            joint_parent=user_profile.joint_parent,
            joint_first_child=user_profile.joint_first_child,
            joint_next_sibling=user_profile.joint_next_sibling,
            landmark_rest_positions=mirrored_landmark_rest_positions,
            landmark_rest_bone_weights=user_profile.landmark_rest_bone_weights,
            landmark_rest_bone_indices=user_profile.landmark_rest_bone_indices,
            hand_scale=user_profile.hand_scale,
            mesh_vertices=mirrored_mesh_vertices,
            mesh_triangles=user_profile.mesh_triangles,
            dense_bone_weights=user_profile.dense_bone_weights,
            joint_limits=user_profile.joint_limits,
        )

    vertices = skin_vertices_np(user_profile, joint_angles)
    triangles = user_profile.mesh_triangles.numpy()
    return vertices, triangles

# ==================== 高性能Matplotlib渲染 =====================

def plot_hand_mesh_matplotlib(joint_angles, flip=False, figsize=(8, 6), dpi=80, 
                             color=(0.94, 0.88, 0.82), edge_color=(0.4, 0.4, 0.4, 0.5),
                             auto_range=False):
    """
    使用Matplotlib绘制手部网格 - 性能优化版本
    """
    vertices, triangles = skin_mesh_from_angles(joint_angles, flip=flip)
    
    # 创建图形
    fig = plt.figure(figsize=figsize, dpi=dpi)
    ax = fig.add_subplot(111, projection='3d')
    
    # 创建多边形集合
    poly_collection = Poly3DCollection(
        vertices[triangles.astype(int)],
        facecolors=[color] * len(triangles),
        edgecolors=edge_color,
        linewidths=0.3,
        alpha=1.0
    )
    
    ax.add_collection3d(poly_collection)
    
    # 设置坐标轴范围
    if auto_range:
        x_min, x_max = vertices[:, 0].min(), vertices[:, 0].max()
        y_min, y_max = vertices[:, 1].min(), vertices[:, 1].max()
        z_min, z_max = vertices[:, 2].min(), vertices[:, 2].max()
        margin = 20
        ax.set_xlim([x_min - margin, x_max + margin])
        ax.set_ylim([y_min - margin, y_max + margin])
        ax.set_zlim([z_min - margin, z_max + margin])
    else:
        # 固定范围（更快）
        ax.set_xlim([-50, 150])
        ax.set_ylim([-100, 50]) 
        ax.set_zlim([-50, 100])
    
    # 固定视角
    ax.view_init(elev=15, azim=-90)
    
    # 隐藏坐标轴
    ax.set_axis_off()
    
    # 紧凑布局
    plt.tight_layout(pad=0)
    
    return fig, ax

def fig_to_array_matplotlib(fig, scale=1):
    """将Matplotlib图形转换为numpy数组 - 优化版本"""
    # 应用缩放因子
    if scale != 1:
        fig.set_dpi(fig.get_dpi() * scale)
    
    fig.canvas.draw()
    
    # 直接获取RGB缓冲区
    #buf = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
    buf = np.frombuffer(fig.canvas.tostring_argb(), dtype=np.uint8)
    buf = buf.reshape(fig.canvas.get_width_height()[::-1] + (4,))
    buf = buf[:, :, 1:]  # 去掉alpha通道，保留RGB
    
    # 立即关闭图形释放内存
    plt.close(fig)
    
    return buf

# ==================== 保持原有接口的函数 =====================

def plot_hand_mesh(
    joint_angles,
    color="lightpink",
    opacity=1.0,
    flip=False,
    show_triangles=False,
    auto_range=False,
    clean_background=True,
    **mesh_kwargs,
):
    """
    兼容性包装器 - 使用快速Matplotlib版本
    保持与原函数相同的接口
    """
    # 将颜色名称转换为RGB
    color_map = {
        "lightpink": (1.0, 0.71, 0.76),
        "pink": (1.0, 0.75, 0.8),
        "blue": (0.0, 0.0, 1.0),
        "red": (1.0, 0.0, 0.0),
    }
    rgb_color = color_map.get(color, (1.0, 0.75, 0.8))
    
    fig, ax = plot_hand_mesh_matplotlib(
        joint_angles, 
        flip=flip, 
        color=rgb_color,
        auto_range=auto_range
    )
    
    return fig

def fig_to_array(fig, scale=1):
    """兼容性包装器"""
    return fig_to_array_matplotlib(fig, scale=scale)

def remove_alpha_channel(frames):
    """移除alpha通道"""
    if frames.shape[-1] == 4:
        return frames[..., :3]
    return frames

def _joint_angles_to_frame(joint_angles, **kwargs):
    """单帧处理函数 - 使用Matplotlib优化版本"""
    fig = plot_hand_mesh(joint_angles=joint_angles, **kwargs)
    frame_array = fig_to_array(fig, scale=kwargs.get('scale', 1))
    return frame_array

def joint_angles_to_frames(joint_angles_t, **kwargs):
    """串行生成帧"""
    frames = np.array([
        _joint_angles_to_frame(joint_angles=joint_angles, **kwargs)
        for joint_angles in tqdm(joint_angles_t, desc="生成帧")
    ])
    return frames

def joint_angles_to_frames_parallel(joint_angles, n_jobs=8, **kwargs):
    """
    并行生成帧 - 高性能版本
    使用Matplotlib替代Plotly，大幅提升速度
    """
    print(f"🚀 开始并行生成 {len(joint_angles)} 帧 (使用 {n_jobs} 个进程)")
    
    # 修复参数传递问题
    def _safe_frame_generation(ja):
        """安全的单帧生成函数，避免参数传递问题"""
        try:
            # 复制kwargs并移除可能的问题参数
            safe_kwargs = kwargs.copy()
            # 确保只传递有效的参数
            valid_keys = ['flip', 'color', 'opacity', 'auto_range', 'scale']
            safe_kwargs = {k: v for k, v in safe_kwargs.items() if k in valid_keys}
            
            return _joint_angles_to_frame(ja, **safe_kwargs)
        except Exception as e:
            print(f"生成帧时出错: {e}")
            # 返回黑色帧作为占位符
            return np.zeros((480, 640, 3), dtype=np.uint8)
    
    frames = np.array(
        ProgressParallel(n_jobs=n_jobs, total=len(joint_angles))(
            delayed(_safe_frame_generation)(ja) for ja in joint_angles
        )
    )
    
    print(f"✅ 并行生成完成: {len(frames)} 帧")
    return frames

def generate_hand_mesh_from_joint_angles(
    joint_angles, color="lightpink", flip=False, opacity=0.5, **mesh_kwargs
):
    """兼容性函数 - 返回Matplotlib图形"""
    return plot_hand_mesh(joint_angles, color=color, flip=flip, opacity=opacity)

def generate_hand_mesh_frames_from_joint_angles(
    joint_angles, color="lightpink", flip=False, opacity=0.5, **mesh_kwargs
):
    """兼容性函数"""
    frames = []
    initial_data = None
    for ind, ja in tqdm(enumerate(joint_angles), desc="生成网格帧"):
        hand_mesh = generate_hand_mesh_from_joint_angles(
            joint_angles=ja,
            color=color,
            flip=flip,
            opacity=opacity,
            **mesh_kwargs,
        )
        # 简化实现
        if initial_data is None:
            initial_data = [hand_mesh]
        frames.append(hand_mesh)
    return initial_data, frames

# ==================== 其他兼容性函数 =====================

def _set_3d_plot_layout(fig, auto_range=False, flip=False, clean_background=True):
    """简化实现"""
    return fig

def frame_args(duration):
    return {
        "frame": {"duration": duration},
        "mode": "immediate",
        "fromcurrent": True,
        "transition": {"duration": duration, "easing": "linear"},
    }

def animate_frames(initial_data, frames):
    """简化实现"""
    # 返回一个简单的图形
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.text(0.5, 0.5, "动画功能需使用原始Plotly版本", 
            ha='center', va='center', transform=ax.transAxes)
    ax.set_axis_off()
    return fig

def get_plotly_animation_for_joint_angles(
    joint_angles, flip=False, title="", color="lightpink", 
    opacity=1.0, auto_range=False, clean_background=True
):
    """简化实现"""
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.text(0.5, 0.5, "动画功能需使用原始Plotly版本", 
            ha='center', va='center', transform=ax.transAxes)
    ax.set_title(title)
    ax.set_axis_off()
    return fig

# ==================== 工具函数 =====================

def preview_first_frame(joint_angles):
    """预览第一帧"""
    print("👀 预览第一帧...")
    fig, ax = plot_hand_mesh_matplotlib(joint_angles)
    ax.set_title("First Frame Preview - 高性能版本")
    plt.show()
    plt.close(fig)

def batch_precompute_vertices(joint_angles_batch, flip=False):
    """批量预计算顶点 - 用于性能优化"""
    hand_model = load_default_hand_model()
    
    if flip:
        hand_model = hand_model._replace(
            mesh_vertices=hand_model.mesh_vertices.clone()
        )
        hand_model.mesh_vertices[..., 0] *= -1
    
    with torch.no_grad():
        vertices_batch = skin_vertices(
            hand_model,
            torch.from_numpy(joint_angles_batch).float()
        ).numpy()
    
    triangles = hand_model.mesh_triangles.numpy()
    return vertices_batch, triangles